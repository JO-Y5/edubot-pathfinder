
# Phase 6 – Hybrid + Explainability++ + CAT-lite + Coach + RateLimit + SEO + Freemium

## Migrations
- `user_profiles` (plan basic/pro, role student/coach/admin)

## Edge
- `recs-hybrid` with rate limit and freemium cap.
- `assessment-cat` (bank.json) + early stop.

## Frontend
- `ProGate` component, `CoachView` page, `seo.ts` + `robots.txt`, `gen_sitemap.mjs`.

### Commands
```bash
supabase migration up
supabase functions deploy recs-hybrid
supabase functions deploy assessment-cat
SITE_ORIGIN="https://yourdomain.com" SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... node scripts/gen_sitemap.mjs > public/sitemap.xml
```
