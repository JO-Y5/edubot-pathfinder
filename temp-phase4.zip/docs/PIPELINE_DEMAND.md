
# Demand & Salary Pipeline (CSV → Supabase)

Use this pipeline to refresh `careers.demand` and `careers.salary_egp` weekly.

1) Export a CSV (from Wuzzuf/Forasna scrape or partner data) with columns:
```
slug,demand,p50,p90
data-analyst,76,18500,36000
...
```

2) Run the updater (reuses script from Enhancement Pack):
```bash
SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... node scripts/update_demand.mjs data/demand.csv
```

Tips:
- Keep `slug` stable.
- If a career is missing, add it first to `careers` then re-run.
