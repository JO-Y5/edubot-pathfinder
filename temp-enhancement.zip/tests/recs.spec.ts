
// tests/recs.spec.ts
import { describe, it, expect } from 'vitest';

function cosine(a: Record<string, number>, b: Record<string, number>) {
  const keys = Array.from(new Set([...Object.keys(a), ...Object.keys(b)]));
  let dot=0, na=0, nb=0;
  for (const k of keys) {
    const x = a[k] || 0, y = b[k] || 0;
    dot += x*y; na += x*x; nb += y*y;
  }
  return dot / ((Math.sqrt(na) * Math.sqrt(nb)) || 1);
}

it('cosine similarity behaves', () => {
  const u = { R:0.2, I:0.6, A:0.1, S:0.2, E:0.2, C:0.5 };
  const c = { R:0.2, I:0.6, A:0.1, S:0.2, E:0.2, C:0.5 };
  expect(cosine(u,c)).toBeCloseTo(1, 3);
});

it('cosine smaller for different vectors', () => {
  const u = { R:0.8, I:0.0, A:0.0, S:0.0, E:0.0, C:0.0 };
  const c = { R:0.0, I:0.8, A:0.0, S:0.0, E:0.0, C:0.0 };
  expect(cosine(u,c)).toBeLessThan(0.2);
});
