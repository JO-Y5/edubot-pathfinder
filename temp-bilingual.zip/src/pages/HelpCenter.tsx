
import { useTranslation } from 'react-i18next';
export default function HelpCenter(){
  const { t } = useTranslation();
  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-bold">{t('help_center')}</h1>
      <div className="mt-4 grid gap-4">
        <details className="p-4 border rounded-2xl">
          <summary className="font-semibold">كيف أبدأ التقييم؟ / How to start the assessment?</summary>
          <p className="mt-2 text-sm">اضغط “{t('cta_start')}” من الصفحة الرئيسية…</p>
        </details>
        <details className="p-4 border rounded-2xl">
          <summary className="font-semibold">كيف أرقّي للخطة Pro؟ / How to upgrade?</summary>
          <p className="mt-2 text-sm">من صفحة “{t('nav_pricing')}” سيتم تحويلك للدفع.</p>
        </details>
      </div>
    </div>
  );
}
