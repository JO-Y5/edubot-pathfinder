
// src/contexts/OrgContext.tsx
import React, { createContext, useContext, useEffect, useState } from "react";

type Org = { id:string; name:string; plan:string };
type OrgCtx = { org: Org|null; setOrg: (o:Org|null)=>void; orgs: Org[] };

const Ctx = createContext<OrgCtx>({ org:null, setOrg: ()=>{}, orgs: [] });

export function OrgProvider({ children }: {children: React.ReactNode}) {
  const [org, setOrg] = useState<Org|null>(null);
  const [orgs, setOrgs] = useState<Org[]>([]);
  useEffect(()=>{
    const url = import.meta.env.VITE_SUPABASE_URL;
    const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
    fetch(`${url}/rest/v1/organizations?select=id,name,plan`, { headers: { apikey:key, Authorization:`Bearer ${key}` }})
      .then(r=>r.json()).then(setOrgs).catch(()=>setOrgs([]));
  }, []);
  return <Ctx.Provider value={{ org, setOrg, orgs }}>{children}</Ctx.Provider>
}
export function useOrg(){ return useContext(Ctx); }
