
// scripts/aggregate_analytics.mjs
// Roll up events into metrics_daily, cohort_retention, funnel_daily.
// Usage: SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... node scripts/aggregate_analytics.mjs

const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_ROLE = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!SUPABASE_URL || !SERVICE_ROLE) { console.error("Missing env"); process.exit(1); }
const headers = { apikey: SERVICE_ROLE, Authorization:`Bearer ${SERVICE_ROLE}`, "Content-Type":"application/json" };

function fmtDay(d){ return new Date(d).toISOString().slice(0,10); }

// 1) Pull last 35 days of events/results
const since = new Date(Date.now()-35*24*60*60*1000).toISOString();
const [resEvents, resResults] = await Promise.all([
  fetch(`${SUPABASE_URL}/rest/v1/events?select=user_id,name,props,created_at&created_at=gte.${since}`, { headers }),
  fetch(`${SUPABASE_URL}/rest/v1/results?select=user_id,created_at&created_at=gte.${since}`, { headers })
]);
const events = await resEvents.json();
const results = await resResults.json();

// 2) metrics_daily
const byDayMetric = new Map(); // key: day|metric -> value
function inc(day, metric, by=1){ const k = `${day}|${metric}`; byDayMetric.set(k, (byDayMetric.get(k)||0) + by); }

for (const r of results) inc(fmtDay(r.created_at), "assessment_completes", 1);
for (const e of events) {
  const d = fmtDay(e.created_at);
  if (e.name === "assessment_start") inc(d, "assessment_starts", 1);
  if (e.name === "rec_clicked") inc(d, "rec_clicks", 1);
  if (e.name === "plan_added") inc(d, "plan_adds", 1);
  if (e.name === "course_completed") inc(d, "course_completes", 1);
}
// active users ~ any event or result that day (unique)
const activeSet = new Map();
for (const e of events) { const d=fmtDay(e.created_at); const s = activeSet.get(d)||new Set(); s.add(e.user_id); activeSet.set(d,s); }
for (const r of results) { const d=fmtDay(r.created_at); const s = activeSet.get(d)||new Set(); s.add(r.user_id); activeSet.set(d,s); }
for (const [day, set] of activeSet) inc(day, "active_users", set.size);

const mdRows = [];
for (const [k, v] of byDayMetric) {
  const [day, metric] = k.split("|");
  mdRows.push({ day, metric, value: v });
}
if (mdRows.length) {
  await fetch(`${SUPABASE_URL}/rest/v1/metrics_daily`, { method:"POST", headers, body: JSON.stringify(mdRows) });
}

// 3) cohort_retention: cohort by signup date from earliest event per user
const firstSeen = new Map();
for (const e of events) if (!firstSeen.has(e.user_id)) firstSeen.set(e.user_id, e.created_at);
for (const r of results) if (!firstSeen.has(r.user_id)) firstSeen.set(r.user_id, r.created_at);

const cohorts = new Map(); // cohort_day -> { users:Set, days: Map<day_n, retainedSet> }
for (const [uid, ts] of firstSeen) {
  const cohortDay = fmtDay(ts);
  if (!cohorts.has(cohortDay)) cohorts.set(cohortDay, { users: new Set(), days: new Map() });
  cohorts.get(cohortDay).users.add(uid);
}
function dayDiff(a,b){ return Math.round((new Date(b)-new Date(a))/(24*3600*1000)); }
function markRetained(uid, cohortDay, ts){
  const d = dayDiff(cohortDay, fmtDay(ts));
  if (d < 0 || d > 30) return;
  const map = cohorts.get(cohortDay).days;
  const set = map.get(d) || new Set();
  set.add(uid);
  map.set(d, set);
}
for (const e of events) {
  const cohortDay = fmtDay(firstSeen.get(e.user_id));
  markRetained(e.user_id, cohortDay, e.created_at);
}
for (const r of results) {
  const cohortDay = fmtDay(firstSeen.get(r.user_id));
  markRetained(r.user_id, cohortDay, r.created_at);
}
const cohortRows = [];
for (const [cohortDay, data] of cohorts) {
  const total = data.users.size;
  for (let d=0; d<=30; d++) {
    const retained = (data.days.get(d) || new Set()).size;
    cohortRows.push({ cohort_date: cohortDay, day_n: d, users: total, retained });
  }
}
if (cohortRows.length) {
  await fetch(`${SUPABASE_URL}/rest/v1/cohort_retention`, { method:"POST", headers, body: JSON.stringify(cohortRows) });
}

// 4) funnel_daily (3-step)
const funnel = new Map(); // day -> { s1,s2,s3 }
function f(day){ if(!funnel.has(day)) funnel.set(day, { step1:0, step2:0, step3:0 }); return funnel.get(day); }
for (const e of events) if (e.name==="assessment_start") f(fmtDay(e.created_at)).step1++;
for (const r of results) f(fmtDay(r.created_at)).step2++;
for (const e of events) if (e.name==="rec_clicked" || e.name==="plan_added") f(fmtDay(e.created_at)).step3++;
const funnelRows = [];
for (const [day, v] of funnel) funnelRows.push({ day, step1:v.step1, step2:v.step2, step3:v.step3 });
if (funnelRows.length) await fetch(`${SUPABASE_URL}/rest/v1/funnel_daily`, { method:"POST", headers, body: JSON.stringify(funnelRows) });

console.log("Aggregation done:", { md: mdRows.length, cohorts: cohortRows.length, funnel: funnelRows.length });
