
import { useTranslation } from 'react-i18next';

export default function Pricing(){
  const EDGE = import.meta.env.VITE_EDGE_URL;
  const { t } = useTranslation();
  async function checkout(mode:'personal'|'org'){
    const res = await fetch(`${EDGE}/billing-checkout`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ mode, user_id: '' }) });
    const data = await res.json();
    if (data?.url) window.location.href = data.url;
  }
  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-center">{t('pricing_title')}</h1>
      <div className="grid md:grid-cols-3 gap-4 mt-8">
        <div className="border rounded-2xl p-6">
          <h2 className="font-bold text-xl">{t('free')}</h2>
          <ul className="text-sm mt-2 list-disc list-inside"><li>Basic assessment</li><li>Limited recommendations</li></ul>
          <button className="mt-4 w-full border rounded-lg py-2">{t('start_free')}</button>
        </div>
        <div className="border rounded-2xl p-6 shadow-lg">
          <h2 className="font-bold text-xl">{t('pro')}</h2>
          <ul className="text-sm mt-2 list-disc list-inside"><li>Advanced recommendations</li><li>Detailed reports</li><li>AI Mentor</li></ul>
          <button onClick={()=>checkout('personal')} className="mt-4 w-full bg-black text-white rounded-lg py-2">{t('subscribe_now')}</button>
        </div>
        <div className="border rounded-2xl p-6">
          <h2 className="font-bold text-xl">{t('org')}</h2>
          <ul className="text-sm mt-2 list-disc list-inside"><li>Teams/Students management</li><li>Org dashboards</li><li>Monthly invoicing</li></ul>
          <button onClick={()=>checkout('org')} className="mt-4 w-full bg-black text-white rounded-lg py-2">{t('subscribe_now')}</button>
        </div>
      </div>
    </div>
  );
}
