
// supabase/functions/weights-learn/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

type Weights = { alpha:number; beta:number; gamma:number };

function normalizeWeights(w: Weights): Weights {
  const sum = w.alpha + w.beta + w.gamma;
  if (!sum) return { alpha:0.6, beta:0.25, gamma:0.15 };
  return { alpha: +(w.alpha/sum).toFixed(3), beta:+(w.beta/sum).toFixed(3), gamma:+(w.gamma/sum).toFixed(3) };
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const headers = { apikey: SERVICE_ROLE, Authorization:`Bearer ${SERVICE_ROLE}` };

    const since = new Date(Date.now() - 30*24*60*60*1000).toISOString();
    const eRes = await fetch(`${SUPABASE_URL}/rest/v1/events?select=name,props,created_at&created_at=gte.${since}`, { headers });
    const events = await eRes.json();

    let clicks=0, saves=0, completes=0;
    for (const e of events) {
      if (e.name === 'rec_clicked') clicks++;
      if (e.name === 'plan_added') saves++;
      if (e.name === 'course_completed') completes++;
    }
    const w = normalizeWeights({
      alpha: clicks || 1,
      beta: saves || 1,
      gamma: completes || 1
    });

    const body = [{ key: 'recs_weights', value: w }];
    const up = await fetch(`${SUPABASE_URL}/rest/v1/settings`, {
      method: "POST",
      headers: { ...headers, "Content-Type":"application/json", Prefer:"resolution=merge-duplicates" },
      body: JSON.stringify(body)
    });
    if (!up.ok) throw new Error(await up.text());

    return new Response(JSON.stringify({ ok:true, weights:w, sampleCounts:{clicks,saves,completes} }), { headers: { ...CORS, "Content-Type":"application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: `${e}` }), { status: 400, headers: { ...CORS, "Content-Type":"application/json" } });
  }
});
