
// supabase/functions/recs-hybrid/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { allow } from "../_lib/rate_limit.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function cosine(a: Record<string, number>, b: Record<string, number>) {
  const keys = Array.from(new Set([...Object.keys(a), ...Object.keys(b)]));
  let dot=0, na=0, nb=0;
  for (const k of keys) {
    const x = a[k] || 0, y = b[k] || 0;
    dot += x*y; na += x*x; nb += y*y;
  }
  return dot / ((Math.sqrt(na) * Math.sqrt(nb)) || 1);
}

function jaccard(a: string[] = [], b: string[] = []) {
  const A = new Set(a), B = new Set(b);
  const inter = [...A].filter(x => B.has(x)).length;
  const uni = new Set([...A, ...B]).size || 1;
  return inter / uni;
}

function overlap(arr: string[] = [], arr2: string[] = []) {
  const A = new Set(arr), B = new Set(arr2);
  return [...A].filter(x => B.has(x));
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  const ip = req.headers.get("x-forwarded-for") || "anon";
  if (!allow(ip, 120, 60_000)) return new Response(JSON.stringify({ error: "Rate limited" }), { status: 429, headers: { ...CORS, "Content-Type":"application/json" } });

  try {
    const { user_id, limit = 12 } = await req.json();
    if (!user_id) throw new Error("Missing user_id");

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const headers = { apikey: SERVICE_ROLE, Authorization: `Bearer ${SERVICE_ROLE}` };

    let plan = "basic";
    try {
      const pRes = await fetch(`${SUPABASE_URL}/rest/v1/user_profiles?id=eq.${user_id}&select=plan&limit=1`, { headers });
      const p = await pRes.json();
      plan = p?.[0]?.plan || "basic";
    } catch {}

    const cap = plan === "pro" ? Math.min(limit, 12) : Math.min(limit, 5);

    const rRes = await fetch(`${SUPABASE_URL}/rest/v1/results?user_id=eq.${user_id}&select=*&order=created_at.desc&limit=1`, { headers });
    const results = await rRes.json();
    const last = results?.[0];
    if (!last) throw new Error("No assessment results");

    const cRes = await fetch(`${SUPABASE_URL}/rest/v1/careers?select=*`, { headers });
    const careers = await cRes.json();

    const fbRes = await fetch(`${SUPABASE_URL}/rest/v1/feedback?user_id=eq.${user_id}&select=career_id,label`, { headers });
    const fbs = await fbRes.json();
    const liked = new Set(fbs.filter((x:any)=>x.label==='like').map((x:any)=>x.career_id));

    const evRes = await fetch(`${SUPABASE_URL}/rest/v1/events?select=name,props`, { headers });
    const events = await evRes.json();
    const pop = new Map<string, number>();
    for (const e of events) {
      const cid = e?.props?.careerId || e?.props?.itemId;
      if (!cid) continue;
      const w = e.name === 'rec_clicked' ? 1 : e.name === 'plan_added' ? 2 : e.name === 'course_completed' ? 3 : 0.5;
      pop.set(cid, (pop.get(cid) || 0) + w);
    }

    const weights = { content: 0.6, popularity: 0.25, matchSkills: 0.15 };
    const userSkills = new Set<string>();

    const scored = careers.map((c:any)=>{
      const sContent = cosine(last.riasec||{}, c.riasec_proto||{});
      const sPop = Math.min((pop.get(c.id) || 0) / 20, 1);
      const sMatch = jaccard(c.skills||[], Array.from(userSkills));
      let score = weights.content*sContent + weights.popularity*sPop + weights.matchSkills*sMatch;
      if (liked.has(c.id)) score *= 1.1;

      const have = overlap(Array.from(userSkills), c.skills||[]);
      const need = (c.skills||[]).filter((s:string)=>!have.includes(s)).slice(0,3);
      const rationale = [
        sContent>0.6 ? "توافق قوي مع نمط شخصيتك" : "توافق متوسط مع نمط شخصيتك",
        sPop>0.4 ? "إقبال جيّد من المستخدمين" : "",
        have.length ? `مهارات مشتركة: ${have.slice(0,3).join(", ")}` : "",
        need.length ? `نواقص قابلة للسد: ${need.join(", ")}` : ""
      ].filter(Boolean).join(" • ");

      return { ...c, score: +score.toFixed(3), rationale, explain: { have, need } };
    }).sort((a:any,b:any)=>b.score-a.score).slice(0, cap);

    return new Response(JSON.stringify({ plan, limit: cap, items: scored }), { headers: { ...CORS, "Content-Type":"application/json" }});
  } catch (e) {
    return new Response(JSON.stringify({ error: `${e}` }), { status: 400, headers: { ...CORS, "Content-Type":"application/json" }});
  }
});
