
// src/i18n/index.ts
import { useEffect, useState } from 'react';
import ar from './ar.json';
import en from './en.json';

type Dict = Record<string, string>;

const dicts: Record<string, Dict> = { ar, en };

export function useI18n() {
  const [lang, setLang] = useState(localStorage.getItem('lang') || 'ar');
  const t = (k: string) => (dicts[lang] && dicts[lang][k]) || k;
  useEffect(()=>{ localStorage.setItem('lang', lang); document.dir = lang === 'ar' ? 'rtl' : 'ltr'; }, [lang]);
  return { t, lang, setLang };
}
