
// src/pages/ReviewQueue.tsx
import React, { useEffect, useState } from "react";

export default function ReviewQueue() {
  const url = import.meta.env.VITE_SUPABASE_URL;
  const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  const EDGE = import.meta.env.VITE_EDGE_URL;

  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    const res = await fetch(`${url}/rest/v1/review_queue?select=id,provider_mapping_id,state,assigned_to`, { headers:{ apikey:key, Authorization:`Bearer ${key}` } });
    const arr = await res.json();
    setRows(arr); setLoading(false);
  }

  useEffect(()=>{ load(); }, []);

  async function assignMe() {
    const user_id = (window as any).user?.id;
    const res = await fetch(`${EDGE}/review-assign`, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ user_id }) });
    const data = await res.json();
    alert(data?.message || `Assigned item ${data?.id}`);
    load();
  }

  async function submit(item:any, decision:'approved'|'rejected') {
    await fetch(`${EDGE}/review-submit`, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ queue_id: item.id, mapping_id: item.provider_mapping_id, decision, notes: '' }) });
    load();
  }

  if (loading) return <div className="p-6">Loading...</div>;

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-bold">مراجعة بشرية (Human-in-the-Loop)</h1>
      <button onClick={assignMe} className="px-3 py-2 rounded bg-black text-white text-sm">Assign me</button>
      <table className="w-full text-sm mt-4">
        <thead><tr className="border-b"><th>ID</th><th>State</th><th>Actions</th></tr></thead>
        <tbody>
          {rows.map((r:any)=>(
            <tr key={r.id} className="border-b">
              <td className="py-1">{r.id.slice(0,8)}</td>
              <td>{r.state}</td>
              <td className="space-x-2">
                <button onClick={()=>submit(r,'approved')} className="px-2 py-1 border rounded text-xs">Approve</button>
                <button onClick={()=>submit(r,'rejected')} className="px-2 py-1 border rounded text-xs">Reject</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
