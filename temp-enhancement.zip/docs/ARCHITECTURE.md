
# Architecture – Enhancement Pack (2025-10-23)

- **DB**: `careers`, `courses`, `results`, `recs`, `feedback`, `plan_items` (Postgres on Supabase).
- **RLS**: users can only see/insert their own rows in `results`, `recs`, `feedback`, `plan_items`.
- **Edge Functions**: `assessment-score`, `recs`.
- **Recommender**: content-based with feedback prior (+10% like / -10% dislike) and basic diversity.
- **Analytics**: PostHog hooks (`initAnalytics`, `track`, `identify`).
- **Tests**: Vitest unit tests for core math utilities.
- **CI**: GitHub Actions running tests on PR/Push.

## Env
```
VITE_SUPABASE_URL=...
VITE_SUPABASE_PUBLISHABLE_KEY=...
VITE_POSTHOG_KEY=...         # optional
VITE_POSTHOG_HOST=https://app.posthog.com
```
