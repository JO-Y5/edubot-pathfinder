
// src/components/LangSwitcher.tsx
import React from "react";
import { useI18n } from "@/i18n";

export default function LangSwitcher() {
  const { lang, setLang, t } = useI18n();
  return (
    <div className="inline-flex items-center gap-2">
      <label className="text-xs text-gray-600">{t('language')}</label>
      <select value={lang} onChange={e=>setLang(e.target.value)} className="text-xs border rounded px-2 py-1">
        <option value="ar">العربية</option>
        <option value="en">English</option>
      </select>
    </div>
  );
}
