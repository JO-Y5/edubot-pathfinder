
// src/pages/CoachView.tsx
import React, { useEffect, useState } from "react";
type Row = { user_id:string; riasec:any; big5:any; created_at:string };
export default function CoachView() {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(()=>{
    async function load() {
      const url = import.meta.env.VITE_SUPABASE_URL;
      const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
      const res = await fetch(`${url}/rest/v1/results?select=user_id,riasec,big5,created_at&order=created_at.desc&limit=100`, {
        headers: { apikey:key, Authorization:`Bearer ${key}` }
      });
      const data = await res.json();
      setRows(data); setLoading(false);
    } load();
  }, []);
  if (loading) return <div className="p-6">Loading...</div>;
  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-2xl font-bold">Coach / Guardian View</h1>
      <table className="w-full mt-4 text-sm">
        <thead><tr className="border-b"><th>user</th><th>RIASEC</th><th>Big5</th><th>Created</th></tr></thead>
        <tbody>
          {rows.map((r,i)=>(
            <tr key={i} className="border-b">
              <td className="py-2">{r.user_id.slice(0,8)}</td>
              <td>{Object.entries(r.riasec||{}).map(([k,v])=>`${k}:${Math.round((v as number)*100)}%`).join(" ")}</td>
              <td>{Object.entries(r.big5||{}).map(([k,v])=>`${k}:${Math.round((v as number)*100)}%`).join(" ")}</td>
              <td>{new Date(r.created_at).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
