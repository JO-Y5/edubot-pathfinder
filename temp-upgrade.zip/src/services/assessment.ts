
// src/services/assessment.ts
import { supa } from "@/lib/supa";

export type Answer = { id: string; value: number | string | string[] };

export async function submitAssessment(userId: string, answers: Answer[]) {
  const fnUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/assessment-score`;
  const res = await fetch(fnUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user_id: userId, answers })
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}
