
// supabase/functions/review-assign/index.ts
// Assign next review_queue item (state=todo) to a reviewer (user_id)
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  try {
    const { user_id } = await req.json();
    if (!user_id) throw new Error("user_id required");

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const headers = { apikey: SERVICE_ROLE, Authorization:`Bearer ${SERVICE_ROLE}`, "Content-Type":"application/json" };

    const qRes = await fetch(`${SUPABASE_URL}/rest/v1/review_queue?state=eq.todo&select=id,provider_mapping_id&limit=1`, { headers });
    const item = (await qRes.json())?.[0];
    if (!item) return new Response(JSON.stringify({ message:"No items" }), { headers: { ...CORS, "Content-Type":"application/json" } });

    await fetch(`${SUPABASE_URL}/rest/v1/review_queue?id=eq.${item.id}`, {
      method:"PATCH", headers, body: JSON.stringify({ assigned_to: user_id, state: 'in_progress' })
    });

    return new Response(JSON.stringify(item), { headers: { ...CORS, "Content-Type":"application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 400, headers: { ...CORS, "Content-Type":"application/json" } });
  }
});
