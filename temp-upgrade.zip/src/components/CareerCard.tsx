
// src/components/CareerCard.tsx
import React from "react";

type Props = {
  title: string;
  score: number;
  rationale: string;
  skills?: string[];
  demand?: number;
  salary_egp?: { p50?: number; p90?: number };
  onOpen?: () => void;
};

export default function CareerCard({ title, score, rationale, skills=[], demand=50, salary_egp, onOpen }: Props) {
  const percent = Math.round(score * 100);
  return (
    <div className="rounded-2xl border p-4 shadow-sm hover:shadow-md transition">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">{title}</h3>
        <span className="text-sm px-2 py-1 rounded bg-gray-100">{percent}% fit</span>
      </div>
      <p className="mt-2 text-sm text-gray-600">{rationale}</p>
      <div className="mt-3 text-sm">
        <div className="flex gap-2 flex-wrap">
          {skills.slice(0,6).map((s) => (
            <span key={s} className="px-2 py-1 bg-gray-50 rounded border text-xs">{s}</span>
          ))}
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-gray-700">
          <div>Demand: <strong>{demand}</strong></div>
          <div>Median salary: <strong>{salary_egp?.p50 ? `${salary_egp.p50.toLocaleString()} EGP` : "—"}</strong></div>
        </div>
      </div>
      <div className="mt-4">
        <button onClick={onOpen} className="px-3 py-2 rounded-lg bg-black text-white text-sm">View career</button>
      </div>
    </div>
  );
}
