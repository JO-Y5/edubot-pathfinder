
// scripts/seed.mjs
// Seeds careers and courses into Supabase via REST using SERVICE ROLE key (run locally).

import fs from "fs/promises";

const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_ROLE = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SERVICE_ROLE) {
  console.error("Please set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in env before running.");
  process.exit(1);
}

async function post(table, rows) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
    method: "POST",
    headers: {
      apikey: SERVICE_ROLE,
      Authorization: `Bearer ${SERVICE_ROLE}`,
      "Content-Type": "application/json",
      Prefer: "resolution=merge-duplicates"
    },
    body: JSON.stringify(rows)
  });
  if (!res.ok) throw new Error(await res.text());
  console.log(`Seeded ${rows.length} rows into ${table}`);
}

const careers = JSON.parse(await fs.readFile("data/careers.seed.json", "utf8"));
const courses = JSON.parse(await fs.readFile("data/courses.seed.json", "utf8"));

await post("careers", careers);
await post("courses", courses);
console.log("Seed done ✅");
