
# A11y & UX Guidelines (Quick)

- Use semantic headings and labeled buttons (aria-labels for icons).
- Ensure contrast >= 4.5:1 for text. Prefer system fonts for speed.
- Focus states: Tailwind `focus-visible:ring` on interactive elements.
- Keyboard nav: ensure tab order is logical in onboarding wizard.
- RTL/LTR: i18n toggles `document.dir` automatically; keep layout neutral.
