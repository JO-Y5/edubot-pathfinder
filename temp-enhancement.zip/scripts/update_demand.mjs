
// scripts/update_demand.mjs
// Usage: node scripts/update_demand.mjs data/demand.csv
// CSV columns: slug,demand,p50,p90

import fs from 'fs/promises';
import path from 'path';

const [,, csvPath] = process.argv;
if (!csvPath) {
  console.error("Provide CSV path: node scripts/update_demand.mjs data/demand.csv");
  process.exit(1);
}

const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_ROLE = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!SUPABASE_URL || !SERVICE_ROLE) {
  console.error("Missing SUPABASE_URL or SERVICE_ROLE key in env");
  process.exit(1);
}

const text = await fs.readFile(csvPath, 'utf8');
const rows = text.trim().split(/\r?\n/).slice(1).map(line => {
  const [slug, demand, p50, p90] = line.split(',');
  return { slug, demand: Number(demand || 50), salary_egp: { p50: Number(p50||0), p90: Number(p90||0) } };
});

for (const r of rows) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/careers?slug=eq.${r.slug}`, {
    method: "PATCH",
    headers: {
      apikey: SERVICE_ROLE,
      Authorization: `Bearer ${SERVICE_ROLE}`,
      "Content-Type": "application/json",
      Prefer: "resolution=merge-duplicates"
    },
    body: JSON.stringify({ demand: r.demand, salary_egp: r.salary_egp })
  });
  if (!res.ok) console.error("Failed:", r.slug, await res.text());
  else console.log("Updated:", r.slug);
}
console.log("Demand update finished.");
