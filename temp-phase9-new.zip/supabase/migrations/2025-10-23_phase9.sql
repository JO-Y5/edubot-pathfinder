
-- 2025-10-23_phase9: analytics & experiments

-- Experiments & Variants
create table if not exists public.experiments (
  id uuid primary key default gen_random_uuid(),
  key text unique not null,
  name text not null,
  status text not null default 'draft' check (status in ('draft','running','paused','stopped')),
  targeting jsonb, -- e.g., { country: 'EG', min_version: '1.0.0' }
  start_at timestamptz,
  end_at timestamptz,
  created_at timestamptz default now()
);

create table if not exists public.variants (
  id uuid primary key default gen_random_uuid(),
  experiment_id uuid not null references public.experiments(id) on delete cascade,
  key text not null, -- 'A', 'B', 'C'
  weight int not null default 50 check (weight >= 0 and weight <= 100)
);

create table if not exists public.assignments (
  user_id uuid not null references auth.users(id) on delete cascade,
  experiment_id uuid not null references public.experiments(id) on delete cascade,
  variant_key text not null,
  assigned_at timestamptz default now(),
  primary key (user_id, experiment_id)
);

-- Aggregates (daily rollups)
create table if not exists public.metrics_daily (
  day date not null,
  metric text not null,           -- 'active_users','assessment_starts','assessment_completes','rec_clicks','plan_adds'
  value numeric not null default 0,
  variant_key text,               -- null for overall, or 'A'/'B'
  experiment_id uuid,
  primary key (day, metric, coalesce(variant_key, ''), coalesce(experiment_id, '00000000-0000-0000-0000-000000000000'))
);

-- Cohort retention (signup cohort -> retention day_n)
create table if not exists public.cohort_retention (
  cohort_date date not null,
  day_n int not null,      -- 0..30
  users int not null,
  retained int not null,
  primary key (cohort_date, day_n)
);

-- Funnels (simple 3-step funnel counts per day)
create table if not exists public.funnel_daily (
  day date not null,
  step1 int not null default 0,   -- assessment_start
  step2 int not null default 0,   -- assessment_complete
  step3 int not null default 0,   -- rec_click or plan_added
  primary key (day)
);

-- RLS (read for authenticated), writes by service role
alter table public.experiments enable row level security;
alter table public.variants enable row level security;
alter table public.assignments enable row level security;
alter table public.metrics_daily enable row level security;
alter table public.cohort_retention enable row level security;
alter table public.funnel_daily enable row level security;

create policy if not exists "experiments_read" on public.experiments for select to authenticated using (true);
create policy if not exists "variants_read" on public.variants for select to authenticated using (true);
create policy if not exists "assignments_self_read" on public.assignments for select to authenticated using (user_id = auth.uid());
create policy if not exists "metrics_read" on public.metrics_daily for select to authenticated using (true);
create policy if not exists "cohorts_read" on public.cohort_retention for select to authenticated using (true);
create policy if not exists "funnels_read" on public.funnel_daily for select to authenticated using (true);
