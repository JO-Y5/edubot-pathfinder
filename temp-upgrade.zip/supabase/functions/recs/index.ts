
// supabase/functions/recs/index.ts
// Deno edge function – content-based career recommender with rationale

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function cosine(a: Record<string, number>, b: Record<string, number>) {
  const keys = Array.from(new Set([...Object.keys(a), ...Object.keys(b)]));
  let dot=0, na=0, nb=0;
  for (const k of keys) {
    const x = a[k] || 0, y = b[k] || 0;
    dot += x*y; na += x*x; nb += y*y;
  }
  return dot / ((Math.sqrt(na) * Math.sqrt(nb)) || 1);
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  try {
    const { user_id, limit = 8 } = await req.json();
    if (!user_id) throw new Error("Missing user_id");

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const headers = { apikey: SERVICE_ROLE, Authorization: `Bearer ${SERVICE_ROLE}` };

    // 1) Latest result
    const rRes = await fetch(`${SUPABASE_URL}/rest/v1/results?user_id=eq.${user_id}&select=*&order=created_at.desc&limit=1`, { headers });
    const results = await rRes.json();
    const last = results?.[0];
    if (!last) throw new Error("No assessment results for user");

    // 2) Careers
    const cRes = await fetch(`${SUPABASE_URL}/rest/v1/careers?select=*`, { headers });
    const careers = await cRes.json();

    // 3) Score
    const scored = careers.map((c: any) => {
      const s1 = cosine(last.riasec || {}, c.riasec_proto || {});
      const s2 = (c.demand ?? 50) / 100;
      const s3 = c.salary_egp?.p50 ? Math.min(c.salary_egp.p50 / 30000, 1) : 0.5;
      const score = 0.6*s1 + 0.25*s2 + 0.15*s3;
      const rationale = [
        s1>0.6 ? "توافق قوي مع نمط شخصيتك" : "توافق معقول مع نمط شخصيتك",
        s2>0.6 ? "طلب وظيفي مرتفع حاليًا" : "طلب متوسط في السوق",
        s3>0.5 ? "عائد مالي جيد نسبيًا" : "عائد مالي متوسط"
      ].join(" • ");
      return { ...c, score: +score.toFixed(3), rationale };
    }).sort((a:any,b:any)=>b.score-a.score).slice(0, limit);

    // 4) Snapshot (optional)
    const body = scored.map((c:any)=>({ user_id, target_type:"career", target_id:c.id, score:c.score, rationale:c.rationale }));
    await fetch(`${SUPABASE_URL}/rest/v1/recs`, {
      method: "POST",
      headers: { ...headers, "Content-Type": "application/json", Prefer: "resolution=merge-duplicates" },
      body: JSON.stringify(body)
    }).catch(()=>{});

    return new Response(JSON.stringify(scored), { headers: { ...CORS, "Content-Type": "application/json" }});
  } catch (e) {
    return new Response(JSON.stringify({ error: `${e}` }), { status: 400, headers: { ...CORS, "Content-Type": "application/json" }});
  }
});
