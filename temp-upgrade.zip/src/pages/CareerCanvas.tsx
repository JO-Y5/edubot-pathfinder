
// src/pages/CareerCanvas.tsx
import React from "react";

export default function CareerCanvas() {
  // This is a placeholder detail page; wire it to your router and load career by slug.
  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-bold">Career Canvas</h1>
      <p className="mt-2 text-gray-600">Deep-dive into responsibilities, key skills, local salary ranges, and a 3-course learning path.</p>
      <div className="mt-6 grid gap-4">
        <section className="p-4 rounded-2xl border">
          <h2 className="font-semibold">Summary</h2>
          <p className="mt-2 text-sm text-gray-700">...</p>
        </section>
        <section className="p-4 rounded-2xl border">
          <h2 className="font-semibold">Core Skills</h2>
          <ul className="list-disc list-inside text-sm text-gray-700">
            <li>SQL</li><li>Python</li><li>Data viz</li>
          </ul>
        </section>
        <section className="p-4 rounded-2xl border">
          <h2 className="font-semibold">Local Salary (EGP)</h2>
          <div className="text-sm">Median: 18,000 • p90: 35,000</div>
        </section>
        <section className="p-4 rounded-2xl border">
          <h2 className="font-semibold">Learning Path (3 steps)</h2>
          <ol className="list-decimal list-inside text-sm text-gray-700">
            <li>Intro to Data Analysis (Coursera)</li>
            <li>SQL for Analysts (Udacity/ITI)</li>
            <li>Dashboards with Power BI</li>
          </ol>
        </section>
      </div>
    </div>
  );
}
