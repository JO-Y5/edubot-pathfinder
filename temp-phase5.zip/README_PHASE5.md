
# Phase 5 Pack – AuthGuard + Personal Plan + PDF + Behavior & Adaptive Weights

## Included
- DB migration: `plan_items.status`, `events`, `settings`.
- Edge functions: `weights-learn` (learn weights from events), updated `recs` (reads weights).
- Frontend: `AuthGuard`, `PersonalPlan` page, `events.ts`, `plan.ts`, `pdfExport.ts`.

## Setup
1) Run migrations:
```bash
supabase migration up
```
2) Deploy edge:
```bash
supabase functions deploy weights-learn
supabase functions deploy recs
```
3) Schedule weight learning (via cron/GitHub Actions/Cloud Scheduler) by hitting the function endpoint weekly.
4) Frontend:
- Protect routes with `AuthGuard`:
  ```tsx
  // <Route path="/plan" element={<AuthGuard><PersonalPlan/></AuthGuard>} />
  ```
- Install PDF dependency:
  ```bash
  pnpm add jspdf
  ```
- Emit events where relevant:
  ```ts
  sendEvent(user.id, 'rec_clicked', { careerId });
  sendEvent(user.id, 'plan_added', { itemType:'career', itemId });
  sendEvent(user.id, 'course_completed', { courseId });
  ```
