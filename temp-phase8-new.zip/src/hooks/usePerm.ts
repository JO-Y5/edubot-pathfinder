
// src/hooks/usePerm.ts
import { useEffect, useState } from "react";

export function usePerm(permission: string, org_id?:string, group_id?:string) {
  const [allowed, setAllowed] = useState<boolean>(false);
  useEffect(()=>{
    (async ()=>{
      try {
        const url = import.meta.env.VITE_SUPABASE_URL;
        const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
        const q = [];
        if (org_id) q.push(`org_id=eq.${org_id}`);
        if (group_id) q.push(`group_id=eq.${group_id}`);
        q.push(`permission=eq.${permission}`);
        const res = await fetch(`${url}/rest/v1/permissions?select=id&` + q.join("&"), { headers: { apikey:key, Authorization:`Bearer ${key}` }});
        const rows = await res.json();
        setAllowed((rows||[]).length>0);
      } catch { setAllowed(false); }
    })();
  }, [permission, org_id, group_id]);
  return allowed;
}
