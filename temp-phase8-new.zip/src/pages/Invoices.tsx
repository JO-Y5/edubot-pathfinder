
// src/pages/Invoices.tsx
import React, { useEffect, useState } from "react";
import { listInvoices, generateInvoicePdf } from "@/services/invoices";

export default function Invoices() {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(()=>{ listInvoices().then(setRows).finally(()=>setLoading(false)); }, []);
  if (loading) return <div className="p-6">Loading...</div>;
  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-bold">Invoices</h1>
      <table className="w-full text-sm mt-4">
        <thead><tr className="border-b"><th>Number</th><th>Amount</th><th>Status</th><th>Issued</th><th></th></tr></thead>
        <tbody>
          {rows.map((r:any)=>(
            <tr key={r.id} className="border-b">
              <td className="py-2">{r.number}</td>
              <td>{(r.amount_cents/100).toFixed(2)} {r.currency}</td>
              <td>{r.status}</td>
              <td>{new Date(r.issued_at).toLocaleDateString()}</td>
              <td><button onClick={()=>generateInvoicePdf(r)} className="px-2 py-1 border rounded text-xs">Export PDF</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
