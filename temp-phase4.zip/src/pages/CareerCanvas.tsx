
// src/pages/CareerCanvas.tsx (dynamic)
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useI18n } from "@/i18n";
import { buildLearningPath } from "@/services/learningPath";

type Career = {
  id: string;
  slug: string;
  title: string;
  summary?: string;
  skills?: string[];
  salary_egp?: { p50?: number; p90?: number };
  demand?: number;
};

export default function CareerCanvas() {
  const { slug } = useParams<{slug:string}>();
  const { t } = useI18n();
  const [career, setCareer] = useState<Career|null>(null);
  const [courses, setCourses] = useState<any[]>([]);
  const [path, setPath] = useState<any[]>([]);

  useEffect(()=>{
    const url = import.meta.env.VITE_SUPABASE_URL;
    const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
    async function load() {
      const cRes = await fetch(`${url}/rest/v1/careers?slug=eq.${slug}&select=*`, { headers: { apikey:key, Authorization:`Bearer ${key}` } });
      const c = await cRes.json();
      setCareer(c?.[0]||null);

      const courseRes = await fetch(`${url}/rest/v1/courses?select=*`, { headers: { apikey:key, Authorization:`Bearer ${key}` } });
      const all = await courseRes.json();
      setCourses(all);
    }
    load();
  }, [slug]);

  useEffect(()=>{
    if (career && courses.length) setPath(buildLearningPath(career, courses, 3));
  }, [career, courses]);

  if (!career) return <div className="p-6">Loading...</div>;

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-bold">{t('career_canvas')}: {career.title}</h1>
      <section className="mt-4 p-4 rounded-2xl border">
        <h2 className="font-semibold">Summary</h2>
        <p className="text-sm text-gray-700 mt-2">{career.summary || '...'}</p>
      </section>

      <section className="mt-4 p-4 rounded-2xl border">
        <h2 className="font-semibold">{t('skills')}</h2>
        <div className="flex flex-wrap gap-2 mt-2">
          {(career.skills||[]).map(s=>(<span key={s} className="px-2 py-1 border rounded text-xs">{s}</span>))}
        </div>
      </section>

      <section className="mt-4 p-4 rounded-2xl border grid md:grid-cols-3 gap-4">
        <div>
          <div className="text-xs text-gray-600">{t('salary_local')}</div>
          <div className="text-sm">{t('median')}: <strong>{career.salary_egp?.p50?.toLocaleString()||'—'}</strong></div>
          <div className="text-sm">{t('p90')}: <strong>{career.salary_egp?.p90?.toLocaleString()||'—'}</strong></div>
        </div>
        <div>
          <div className="text-xs text-gray-600">{t('demand')}</div>
          <div className="text-2xl font-bold">{career.demand ?? 50}</div>
        </div>
      </section>

      <section className="mt-4 p-4 rounded-2xl border">
        <h2 className="font-semibold">{t('learning_path')}</h2>
        <ol className="list-decimal list-inside text-sm text-gray-700 mt-2">
          {path.map((c:any, i:number)=>(
            <li key={i}><a className="underline" href={c.url} target="_blank" rel="noreferrer">{c.platform} — {c.title}</a></li>
          ))}
        </ol>
      </section>
    </div>
  );
}
