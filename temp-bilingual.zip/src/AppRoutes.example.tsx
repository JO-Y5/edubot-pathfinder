
import { Routes, Route } from 'react-router-dom';
import Home from '@/pages/Home';
import Pricing from '@/pages/Pricing';
import HelpCenter from '@/pages/HelpCenter';
import LegalTerms from '@/pages/LegalTerms';
import LegalPrivacy from '@/pages/LegalPrivacy';
import AssessmentStart from '@/pages/AssessmentStart';
import AssessmentQuestions from '@/pages/AssessmentQuestions';

export default function AppRoutes(){
  return (
    <Routes>
      <Route path="/" element={<Home/>} />
      <Route path="/pricing" element={<Pricing/>} />
      <Route path="/help" element={<HelpCenter/>} />
      <Route path="/legal/terms" element={<LegalTerms/>} />
      <Route path="/legal/privacy" element={<LegalPrivacy/>} />
      <Route path="/assessment/start" element={<AssessmentStart/>} />
      <Route path="/assessment/questions" element={<AssessmentQuestions/>} />
    </Routes>
  );
}
