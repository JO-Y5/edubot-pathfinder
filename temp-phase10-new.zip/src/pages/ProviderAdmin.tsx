
// src/pages/ProviderAdmin.tsx
import React, { useEffect, useState } from "react";

export default function ProviderAdmin() {
  const url = import.meta.env.VITE_SUPABASE_URL;
  const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  const EDGE = import.meta.env.VITE_EDGE_URL;
  const [providers, setProviders] = useState<any[]>([]);
  const [file, setFile] = useState<File|null>(null);
  const [format, setFormat] = useState<'csv'|'json'>('csv');
  const [prov, setProv] = useState({ slug:'partner', name:'Partner' });

  useEffect(()=>{
    fetch(`${url}/rest/v1/providers?select=*`, { headers:{ apikey:key, Authorization:`Bearer ${key}` }})
      .then(r=>r.json()).then(setProviders);
  }, []);

  async function ingest() {
    if (!file) return alert("اختر ملف CSV/JSON");
    const text = await file.text();
    const res = await fetch(`${EDGE}/provider-sync`, { method:"POST", headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ provider: prov, format, data: text })
    });
    const data = await res.json();
    alert(data?.error || `Imported: ${data?.inserted||0}`);
  }

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-bold">مزودي المحتوى (Integrations)</h1>

      <div className="mt-4 p-4 border rounded-2xl">
        <div className="grid grid-cols-2 gap-3">
          <input className="border px-2 py-1 rounded" placeholder="slug" value={prov.slug} onChange={e=>setProv({...prov, slug:e.target.value})} />
          <input className="border px-2 py-1 rounded" placeholder="name" value={prov.name} onChange={e=>setProv({...prov, name:e.target.value})} />
          <select className="border px-2 py-1 rounded" value={format} onChange={e=>setFormat(e.target.value as any)}>
            <option value="csv">CSV</option>
            <option value="json">JSON</option>
          </select>
          <input type="file" accept={format==='csv'?'.csv':'.json'} onChange={e=>setFile(e.target.files?.[0]||null)} />
        </div>
        <button onClick={ingest} className="mt-4 px-4 py-2 rounded bg-black text-white text-sm">Import</button>
      </div>

      <div className="mt-6">
        <h2 className="font-semibold">Providers</h2>
        <table className="w-full text-sm mt-2">
          <thead><tr><th>Slug</th><th>Name</th><th>Active</th></tr></thead>
          <tbody>
            {providers.map((p:any)=>(<tr key={p.id} className="border-b"><td className="py-1">{p.slug}</td><td>{p.name}</td><td>{p.active?'Yes':'No'}</td></tr>))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
