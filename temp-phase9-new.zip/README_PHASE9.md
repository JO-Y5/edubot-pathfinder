
# Phase 9 – Advanced Analytics & Experiments

## شامل
- **DB**: experiments, variants, assignments، جداول aggregates (metrics_daily, cohort_retention, funnel_daily).
- **Edge**:
  - `experiment-assign`: تعيين حتمي A/B للمستخدمين حسب أوزان المتغيرات.
  - `metrics-report`: API موحدة تعرض series/cohorts/funnel للواجهات.
- **Scripts**:
  - `aggregate_analytics.mjs`: تجميع يومي من `events`/`results` إلى الجداول التجميعية.
  - GitHub Action `analytics.yml` لتشغيل التجميع يوميًا.
- **Frontend**:
  - `AnalyticsDashboard.tsx`: رسوم جدولية (series/cohorts/funnel).
  - `Experiments.tsx`: إنشاء/تشغيل/إدارة تجارب A/B وVariants.

## تشغيل سريع
```bash
supabase migration up
supabase functions deploy experiment-assign
supabase functions deploy metrics-report
node scripts/aggregate_analytics.mjs   # (بيئة) SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=...
```

## استخدام
- عند فتح صفحة (مثلاً اللاندنج) نادِ `experiment-assign` لتحديد المتغير وعرض UI المناسب.
- راقب النتائج في لوحة Analytics؛ فعّل التجميع اليومي عبر GitHub Actions.

## ملاحظات
- نموذج الإسناد افتراضي (count-based). ممكن توسّع لقياس التحويلات حسب أهداف محددة (e.g. start→complete→save).
- لو عندك PostHog/Amplitude، خليه مصدر truth وخلّي الجداول دي مجرد نسخة تلخيصية لواجهة الأدمن.
