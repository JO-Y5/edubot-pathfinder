
// supabase/functions/provider-sync/index.ts
// Ingest courses from CSV/JSON for a provider, upsert into provider_courses and create auto mappings.
// Body: { provider: {slug,name,website,contact_email}, format:'csv'|'json', data:string }
// Edge secrets: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function parseCSV(text: string) {
  const lines = text.trim().split(/\r?\n/);
  const header = lines.shift()!.split(",");
  return lines.map(line => {
    const cols = line.split(",");
    const obj: any = {};
    header.forEach((h,i)=>obj[h.trim()] = (cols[i]||"").trim());
    return obj;
  });
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  try {
    const { provider, format='csv', data } = await req.json();
    if (!provider?.slug) throw new Error("provider.slug required");
    if (!data) throw new Error("data required");

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const headers = { apikey: SERVICE_ROLE, Authorization:`Bearer ${SERVICE_ROLE}`, "Content-Type":"application/json" };

    // upsert provider
    await fetch(`${SUPABASE_URL}/rest/v1/providers`, {
      method:"POST", headers, body: JSON.stringify([{ slug: provider.slug, name: provider.name||provider.slug, website: provider.website||null, contact_email: provider.contact_email||null }]),
    });

    const pRes = await fetch(`${SUPABASE_URL}/rest/v1/providers?slug=eq.${provider.slug}&select=id&limit=1`, { headers });
    const p = (await pRes.json())?.[0];
    if (!p) throw new Error("Provider upsert failed");
    const provider_id = p.id;

    const items = format === 'json' ? JSON.parse(data) : parseCSV(data);

    const upserts = [];
    for (const it of items) {
      const skills = (it.skills || "").toString().split("|").map((s:string)=>s.trim()).filter(Boolean);
      const body = {
        provider_id, ext_id: it.ext_id || it.id || crypto.randomUUID(),
        title: it.title, url: it.url || null, language: it.language || 'ar',
        level: it.level || null, skills, hours: Number(it.hours||0) || null,
        price_cents: it.price_cents? Number(it.price_cents): null, currency: it.currency || 'EGP',
        rating: it.rating? Number(it.rating): null, raw: it
      };
      upserts.push(body);
    }

    if (upserts.length) {
      await fetch(`${SUPABASE_URL}/rest/v1/provider_courses`, { method:"POST", headers, body: JSON.stringify(upserts) });
    }

    // auto mappings (status=auto)
    // naive: match by skill tags to first 1-2 careers that share skills (left for later perfection)
    return new Response(JSON.stringify({ ok:true, inserted: upserts.length }), { headers: { ...CORS, "Content-Type":"application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 400, headers: { ...CORS, "Content-Type":"application/json" } });
  }
});
