
// supabase/functions/metrics-report/index.ts
// Returns metrics for charts (metrics_daily / cohort_retention / funnel_daily)
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  try {
    const qs = new URL(req.url).searchParams;
    const metric = qs.get("metric") || "active_users";
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const headers = { apikey: SERVICE_ROLE, Authorization:`Bearer ${SERVICE_ROLE}` };

    const md = await (await fetch(`${SUPABASE_URL}/rest/v1/metrics_daily?select=day,metric,value,variant_key&metric=eq.${metric}&order=day.asc`, { headers })).json();
    const cohorts = await (await fetch(`${SUPABASE_URL}/rest/v1/cohort_retention?select=cohort_date,day_n,users,retained&order=cohort_date.asc,day_n.asc`, { headers })).json();
    const funnel = await (await fetch(`${SUPABASE_URL}/rest/v1/funnel_daily?select=day,step1,step2,step3&order=day.asc`, { headers })).json();

    return new Response(JSON.stringify({ metrics: md, cohorts, funnel }), { headers: { ...CORS, "Content-Type":"application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 400, headers: { ...CORS, "Content-Type":"application/json" } });
  }
});
