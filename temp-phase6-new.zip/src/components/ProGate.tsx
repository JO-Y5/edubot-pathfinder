
// src/components/ProGate.tsx
import React from "react";
export default function ProGate({ current, max }: { current:number; max:number }) {
  const over = current > max;
  if (!over) return null;
  return (
    <div className="p-4 border rounded-2xl bg-amber-50 text-amber-800 mt-3">
      وصلت لأقصى عدد توصيات في خطتك الحالية. فعل <strong>Pro</strong> لعرض المزيد.
    </div>
  );
}
