
// src/lib/seo.ts
export function careerMeta(career: { title:string; summary?:string; slug:string }) {
  const title = `${career.title} — EduBot Pathfinder`;
  const desc = career.summary || `Explore the ${career.title} path: skills, demand, and salary.`;
  const url = `${location.origin}/career/${career.slug}`;
  const og = { title, desc, url, image: `${location.origin}/og-default.png` };
  return og;
}
