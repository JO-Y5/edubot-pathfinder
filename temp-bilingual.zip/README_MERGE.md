
# EduBot – Lovable Bilingual Pack (AR/EN)

## What's inside
- i18n (ar/en): `src/lib/i18n.ts`
- SEO util: `src/lib/seo.ts`
- Navbar/Footer with language toggle
- Home with AR/EN title
- Static pages: HelpCenter, LegalTerms, LegalPrivacy
- Pricing + Stripe checkout
- Assessment two-tracks + banks
- Routes example: `src/AppRoutes.example.tsx`

## Merge steps (Lovable / React-Vite)
1) Copy `src/` into your project.
2) In `main.tsx` add:
   `import '@/lib/i18n';`
3) Wrap app with Router and include `AppNav` + `AppFooter`.
4) Merge routes from `AppRoutes.example.tsx`.
5) Set `.env` -> `VITE_EDGE_URL` and pass real `user_id` in checkout & assessment.
