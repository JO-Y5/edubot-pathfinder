
// src/services/recs.ts
export async function fetchRecs(userId: string, limit = 8) {
  const fnUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/recs`;
  const res = await fetch(fnUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user_id: userId, limit })
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}
