
// src/pages/AdminAdvanced.tsx
import React, { useEffect, useState } from "react";

type Usage = { users:number; last30d:{ assessments:number; clicks:number; saves:number; completes:number } };
type Group = { id:string; name:string };

export default function AdminAdvanced() {
  const [usage, setUsage] = useState<Usage|null>(null);
  const [groups, setGroups] = useState<Group[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<string>("");

  const url = import.meta.env.VITE_SUPABASE_URL;
  const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  const EDGE = import.meta.env.VITE_EDGE_URL;

  useEffect(()=>{
    // load groups
    fetch(`${url}/rest/v1/groups?select=id,name`, { headers:{ apikey:key, Authorization:`Bearer ${key}` }})
      .then(r=>r.json()).then(setGroups).catch(()=>setGroups([]));
  }, []);

  async function loadUsage(scope?: {group_id?:string}) {
    const res = await fetch(`${EDGE}/usage-report`, { method: "POST", headers: { "Content-Type":"application/json" }, body: JSON.stringify(scope||{}) });
    setUsage(await res.json());
  }

  useEffect(()=>{ loadUsage(); }, []);

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-2xl font-bold">لوحة الإدارة المتقدمة</h1>

      <section className="mt-4 p-4 border rounded-2xl">
        <h2 className="font-semibold">الاستخدام (آخر 30 يوم)</h2>
        {usage ? (
          <ul className="list-disc list-inside text-sm mt-2">
            <li>عدد المستخدمين في النطاق: <b>{usage.users}</b></li>
            <li>التقييمات المكتملة: <b>{usage.last30d.assessments}</b></li>
            <li>نقرات التوصيات: <b>{usage.last30d.clicks}</b></li>
            <li>إضافات للخطة: <b>{usage.last30d.saves}</b></li>
            <li>كورسات مكتملة: <b>{usage.last30d.completes}</b></li>
          </ul>
        ) : <div>Loading…</div>}

        <div className="mt-4 flex gap-2 items-center">
          <select value={selectedGroup} onChange={e=>{ setSelectedGroup(e.target.value); loadUsage({ group_id: e.target.value || undefined }); }} className="border rounded px-2 py-1">
            <option value="">All Groups</option>
            {groups.map(g=>(<option key={g.id} value={g.id}>{g.name}</option>))}
          </select>
          <button onClick={()=>loadUsage(selectedGroup?{group_id:selectedGroup}:{})} className="px-3 py-2 rounded bg-black text-white text-sm">تحديث</button>
        </div>
      </section>
    </div>
  );
}
