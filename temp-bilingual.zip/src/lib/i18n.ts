
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  ar: { translation: {
    appName:'EduMentor+',
    home_title:'التوجيه الأكاديمي والمهني',
    home_sub:'اختَر مسارك الأكاديمي والمهني بمساعدة الذكاء الاصطناعي.',
    cta_start:'ابدأ التقييم الآن',
    nav_help:'مركز المساعدة', nav_terms:'شروط الاستخدام', nav_privacy:'سياسة الخصوصية', nav_pricing:'التسعير',
    nav_analytics:'التحليلات', nav_providers:'المزوِّدون', nav_reviews:'المراجعات', nav_mapping:'الربط',
    pricing_title:'خطط الاشتراك', free:'مجاني', pro:'Pro', org:'منظمات', subscribe_now:'اشترك الآن', start_free:'ابدأ مجانًا',
    assessment_choose_title:'اختَر حالتك الدراسية', uni_student:'أنا طالب في الجامعة', hs_student:'أنا طالب في الثانوية',
    university:'الجامعة', faculty:'الكلية', major:'التخصص/الميجور', grade:'السنة الدراسية', target_university:'الجامعة المستهدفة (اختياري)',
    start_questions:'ابدأ الأسئلة', uni_track_title:'تقييم مسار طالب الجامعة', hs_track_title:'تقييم مسار طالب الثانوية', finish_assessment:'إنهاء التقييم',
    help_center:'مركز المساعدة', terms_title:'شروط الاستخدام', privacy_title:'سياسة الخصوصية'
  }},
  en: { translation: {
    appName:'EduMentor+',
    home_title:'Academic & Career Guidance',
    home_sub:'Choose your academic and career path with AI.',
    cta_start:'Start Assessment',
    nav_help:'Help Center', nav_terms:'Terms of Use', nav_privacy:'Privacy Policy', nav_pricing:'Pricing',
    nav_analytics:'Analytics', nav_providers:'Providers', nav_reviews:'Reviews', nav_mapping:'Mapping',
    pricing_title:'Pricing Plans', free:'Free', pro:'Pro', org:'Organizations', subscribe_now:'Subscribe Now', start_free:'Start Free',
    assessment_choose_title:'Select your current stage', uni_student:"I'm a university student", hs_student:"I'm a high-school student",
    university:'University', faculty:'Faculty', major:'Major', grade:'School grade', target_university:'Target university (optional)',
    start_questions:'Start Questions', uni_track_title:'University Track Assessment', hs_track_title:'High-School Track Assessment', finish_assessment:'Finish Assessment',
    help_center:'Help Center', terms_title:'Terms of Use', privacy_title:'Privacy Policy'
  }}
};

i18n.use(initReactI18next).init({ resources, lng:'ar', fallbackLng:'en', interpolation:{ escapeValue:false } });
export default i18n;
