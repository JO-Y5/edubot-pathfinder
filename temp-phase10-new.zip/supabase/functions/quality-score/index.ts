
// supabase/functions/quality-score/index.ts
// Compute quality score per provider_course into content_quality.
// score = 0.4*freshness_norm + 0.3*reliability + 0.2*popularity + 0.1*manual_boost
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const headers = { apikey: SERVICE_ROLE, Authorization:`Bearer ${SERVICE_ROLE}`, "Content-Type":"application/json" };

    const pcRes = await fetch(`${SUPABASE_URL}/rest/v1/provider_courses?select=id,raw,created_at`, { headers });
    const items = await pcRes.json();

    const rows = [];
    for (const it of items) {
      const lastUpdate = it.raw?.last_update || it.raw?.updated_at || it.created_at;
      const days = Math.max(1, Math.round((Date.now() - new Date(lastUpdate).getTime())/(24*3600*1000)));
      const freshness = days;
      const freshness_norm = Math.max(0, Math.min(1, 1 - freshness/365)); // حديث=1، قديم=0
      const provider_reliability = 0.6; // placeholder per provider later
      const popularity = Math.min(1, (it.raw?.enrollments||0) / 1000);
      const manual_boost = 0;

      const score = +(0.4*freshness_norm + 0.3*provider_reliability + 0.2*popularity + 0.1*manual_boost).toFixed(3);
      rows.push({ provider_course_id: it.id, score, freshness, provider_reliability, popularity, manual_boost });
    }

    if (rows.length) {
      await fetch(`${SUPABASE_URL}/rest/v1/content_quality`, { method:"POST", headers, body: JSON.stringify(rows) });
    }

    return new Response(JSON.stringify({ ok:true, updated: rows.length }), { headers: { ...CORS, "Content-Type":"application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 400, headers: { ...CORS, "Content-Type":"application/json" } });
  }
});
