
-- 2025-10-23_phase8: groups/classes + permissions + invoices

-- Groups / Classes
create table if not exists public.groups (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  created_at timestamptz default now()
);
create table if not exists public.class_enrollments (
  group_id uuid not null references public.groups(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'student' check (role in ('student','coach','ta')),
  created_at timestamptz default now(),
  primary key (group_id, user_id)
);

-- Permissions (Feature flags / RBAC rows)
create table if not exists public.permissions (
  id uuid primary key default gen_random_uuid(),
  org_id uuid references public.organizations(id) on delete cascade,
  group_id uuid references public.groups(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  permission text not null, -- e.g., 'view_results','export_pdf','manage_users'
  allow boolean not null default true,
  created_at timestamptz default now()
);

-- Invoices
create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  org_id uuid references public.organizations(id) on delete set null,
  user_id uuid references auth.users(id) on delete set null,
  number text not null,
  amount_cents int not null,
  currency text not null default 'EGP',
  status text not null default 'open' check (status in ('open','paid','void')),
  payload jsonb,
  issued_at timestamptz default now(),
  paid_at timestamptz
);

-- RLS enable
alter table public.groups enable row level security;
alter table public.class_enrollments enable row level security;
alter table public.permissions enable row level security;
alter table public.invoices enable row level security;

-- RLS basic policies
create policy if not exists "groups_org_members"
on public.groups for select
to authenticated
using (exists (select 1 from public.org_memberships m where m.org_id = groups.org_id and m.user_id = auth.uid()));

create policy if not exists "enrollments_self_read"
on public.class_enrollments for select
to authenticated
using (user_id = auth.uid() or exists (select 1 from public.org_memberships m where m.org_id = (select g.org_id from public.groups g where g.id = class_enrollments.group_id) and m.user_id = auth.uid() and m.role in ('owner','admin','coach')));

create policy if not exists "permissions_org_admins"
on public.permissions for select
to authenticated
using (exists (
  select 1 from public.org_memberships m
  where m.org_id = permissions.org_id and m.user_id = auth.uid() and m.role in ('owner','admin')
));

create policy if not exists "invoices_visibility"
on public.invoices for select
to authenticated
using (
  user_id = auth.uid()
  or exists (select 1 from public.org_memberships m where m.org_id = invoices.org_id and m.user_id = auth.uid() and m.role in ('owner','admin'))
);
