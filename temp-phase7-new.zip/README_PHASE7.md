
# Phase 7 – Billing + Paywall + Admin Console + Orgs/Teams

## What’s included
- DB: organizations, org_memberships, subscriptions, entitlements, audit_log + RLS
- Edge: `billing-checkout` (Stripe Checkout), `stripe-webhook` (upsert subs/plan)
- Frontend: Org context, Paywall component, Billing page, Admin Console

## Setup
1) Run migrations:
```bash
supabase migration up
```
2) Edge secrets (Dashboard → Edge Functions → Secrets):
```
STRIPE_SECRET_KEY=sk_live_...
STRIPE_PRICE_PRO=price_...
STRIPE_PRICE_ORG=price_...
SITE_URL=https://yourapp.com
```
3) Deploy:
```bash
supabase functions deploy billing-checkout
supabase functions deploy stripe-webhook
```
4) Frontend:
- Add routes:
```tsx
// <Route path="/billing" element={<Billing/>} />
// <Route path="/admin" element={<AdminConsole/>} />
```
- Wrap app with `OrgProvider`.
- Set `VITE_EDGE_URL` in `.env`.

## Notes
- Webhook endpoint: `https://<supabase>.functions.supabase.co/stripe-webhook` (set in Stripe).
- On successful payment: personal → `user_profiles.plan=pro`, org → `organizations.plan=org`.
- You can extend `entitlements` for feature flags per plan.
