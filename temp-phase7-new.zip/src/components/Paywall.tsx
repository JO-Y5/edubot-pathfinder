
// src/components/Paywall.tsx
import React from "react";

export default function Paywall({ title="Upgrade to Pro", children }: { title?:string; children?:React.ReactNode }) {
  return (
    <div className="p-6 border rounded-2xl text-center">
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="text-sm text-gray-600 mt-2">افتح مزايا الخطة الاحترافية: توصيات أكثر، PDF Branding، عرض الكوتش.</p>
      <div className="mt-4 flex justify-center gap-3">
        <a href="/billing" className="px-4 py-2 rounded bg-black text-white text-sm">Upgrade</a>
        {children}
      </div>
    </div>
  );
}
