
-- 2025-10-23_phase7: organizations + memberships + subscriptions + entitlements + audit

create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  owner_id uuid not null references auth.users(id) on delete cascade,
  plan text not null default 'basic' check (plan in ('basic','pro','org')),
  created_at timestamptz default now()
);

create table if not exists public.org_memberships (
  org_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','coach','member')),
  created_at timestamptz default now(),
  primary key (org_id, user_id)
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  org_id uuid references public.organizations(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade, -- personal plan if org_id is null
  provider text not null default 'stripe',
  status text not null default 'inactive' check (status in ('inactive','active','past_due','canceled')),
  price_id text,
  current_period_end timestamptz,
  created_at timestamptz default now()
);

create table if not exists public.entitlements (
  id uuid primary key default gen_random_uuid(),
  org_id uuid references public.organizations(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  feature text not null, -- e.g., 'recs_limit','coach_view','pdf_branding'
  value jsonb not null,
  created_at timestamptz default now()
);

create table if not exists public.audit_log (
  id uuid primary key default gen_random_uuid(),
  actor uuid references auth.users(id),
  action text not null,
  target text,
  meta jsonb,
  created_at timestamptz default now()
);

-- Basic RLS
alter table public.organizations enable row level security;
alter table public.org_memberships enable row level security;
alter table public.subscriptions enable row level security;
alter table public.entitlements enable row level security;
alter table public.audit_log enable row level security;

-- Policies
create policy if not exists "orgs_owner_read"
on public.organizations for select
to authenticated
using (owner_id = auth.uid());

create policy if not exists "orgs_owner_insert"
on public.organizations for insert
to authenticated
with check (owner_id = auth.uid());

create policy if not exists "members_self_read"
on public.org_memberships for select
to authenticated
using (user_id = auth.uid());

create policy if not exists "members_owner_manage"
on public.org_memberships for all
to authenticated
using (exists (select 1 from public.organizations o where o.id = org_id and o.owner_id = auth.uid()))
with check (exists (select 1 from public.organizations o where o.id = org_id and o.owner_id = auth.uid()));

create policy if not exists "subs_owner_read"
on public.subscriptions for select
to authenticated
using (
  (user_id = auth.uid()) or
  (exists (select 1 from public.organizations o join public.org_memberships m on m.org_id=o.id where m.user_id=auth.uid() and m.org_id = subscriptions.org_id and m.role in ('owner','admin')))
);

create policy if not exists "ent_read"
on public.entitlements for select
to authenticated
using (
  (user_id = auth.uid()) or
  (exists (select 1 from public.org_memberships m where m.user_id=auth.uid() and m.org_id = entitlements.org_id))
);

create policy if not exists "audit_self_read"
on public.audit_log for select
to authenticated
using (actor = auth.uid());
