
// src/pages/AdminConsole.tsx
import React, { useEffect, useState } from "react";

export default function AdminConsole() {
  const url = import.meta.env.VITE_SUPABASE_URL;
  const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  const [orgs, setOrgs] = useState<any[]>([]);
  const [members, setMembers] = useState<any[]>([]);
  const [subs, setSubs] = useState<any[]>([]);

  useEffect(()=>{
    fetch(`${url}/rest/v1/organizations?select=*`, { headers:{ apikey:key, Authorization:`Bearer ${key}`}}).then(r=>r.json()).then(setOrgs);
    fetch(`${url}/rest/v1/org_memberships?select=*`, { headers:{ apikey:key, Authorization:`Bearer ${key}`}}).then(r=>r.json()).then(setMembers);
    fetch(`${url}/rest/v1/subscriptions?select=*`, { headers:{ apikey:key, Authorization:`Bearer ${key}`}}).then(r=>r.json()).then(setSubs);
  }, []);

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-2xl font-bold">لوحة التحكم (Admin)</h1>
      <section className="mt-4">
        <h2 className="font-semibold">Organizations</h2>
        <table className="w-full text-sm mt-2"><tbody>
          {orgs.map((o:any)=>(<tr key={o.id} className="border-b"><td className="py-1">{o.name}</td><td>{o.plan}</td><td>{o.owner_id?.slice(0,8)}</td></tr>))}
        </tbody></table>
      </section>
      <section className="mt-4">
        <h2 className="font-semibold">Memberships</h2>
        <table className="w-full text-sm mt-2"><tbody>
          {members.map((m:any)=>(<tr key={m.org_id+m.user_id} className="border-b"><td className="py-1">{m.org_id?.slice(0,8)}</td><td>{m.user_id?.slice(0,8)}</td><td>{m.role}</td></tr>))}
        </tbody></table>
      </section>
      <section className="mt-4">
        <h2 className="font-semibold">Subscriptions</h2>
        <table className="w-full text-sm mt-2"><tbody>
          {subs.map((s:any)=>(<tr key={s.id} className="border-b"><td className="py-1">{s.provider}</td><td>{s.status}</td><td>{s.price_id}</td><td>{s.current_period_end}</td></tr>))}
        </tbody></table>
      </section>
    </div>
  );
}
