
// scripts/gen_sitemap.mjs
const url = process.env.SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
const origin = process.env.SITE_ORIGIN || "https://example.com";
if (!url || !key) { console.error("Missing env SUPABASE_URL/ SERVICE_ROLE"); process.exit(1); }
const headers = { apikey: key, Authorization: `Bearer ${key}` };
const res = await fetch(`${url}/rest/v1/careers?select=slug`, { headers });
const slugs = (await res.json()).map((r)=>r.slug);
const urls = slugs.map((s)=>`  <url><loc>${origin}/career/${s}</loc></url>`).join("\n");
const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>`;
process.stdout.write(xml);
