
-- 2025-10-23_c: plan status + events + settings + RLS

alter table if exists public.plan_items
  add column if not exists status text not null default 'todo' check (status in ('todo','in_progress','done'));

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  props jsonb,
  created_at timestamptz default now()
);
alter table public.events enable row level security;
create policy if not exists "events_own_insert"
on public.events for insert to authenticated with check (auth.uid() = user_id);
create index if not exists idx_events_user_time on public.events(user_id, created_at);

create table if not exists public.settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz default now()
);
