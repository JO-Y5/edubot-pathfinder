
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

export default function AppFooter(){
  const { t } = useTranslation();
  return (
    <footer className="w-full mt-16 border-t">
      <div className="max-w-6xl mx-auto px-4 py-6 text-xs text-gray-500 flex flex-wrap gap-4">
        <Link to="/help">{t('help_center')}</Link>
        <Link to="/legal/terms">{t('nav_terms')}</Link>
        <Link to="/legal/privacy">{t('nav_privacy')}</Link>
        <span>© {new Date().getFullYear()} {t('appName')}</span>
      </div>
    </footer>
  );
}
