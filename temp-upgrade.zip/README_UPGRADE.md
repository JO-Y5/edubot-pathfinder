
# EduBot Pathfinder – Upgrade Kit (Backend + AI + DB)

This kit adds **production-grade** backend & AI logic to your existing Vite/React + Supabase project.

## What’s included
- **Supabase Postgres** migrations (careers, courses, results, recs) + **RLS** policies.
- **Edge Functions**:
  - `assessment-score`: computes **RIASEC + Big Five** from your questionnaire answers and stores the result.
  - `recs`: content-based recommender that ranks careers and returns **Why this?** rationale.
- **Seed data** for careers & courses (Egypt-focused placeholders you can tweak).
- **Frontend glue** (TS utilities + components) to call functions and render recommendations.
- **Scripts** to seed data via Supabase REST.

> Created: 2025-10-23

---

## Quickstart

1) **Copy** everything in this ZIP to your repo root (it will add/merge these folders):
```
/supabase/functions/assessment-score
/supabase/functions/recs
/supabase/migrations
/src/lib/supa.ts
/src/services/assessment.ts
/src/services/recs.ts
/src/components/CareerCard.tsx
/src/pages/CareerCanvas.tsx
/scripts/seed.mjs
/data/careers.seed.json
/data/courses.seed.json
```

2) **Supabase secrets** (Dashboard → Edge Functions → Secrets):
```
SUPABASE_URL=<your-project-url>
SUPABASE_SERVICE_ROLE_KEY=<service-role-key>
```

3) **Frontend env** (`.env`):
```
VITE_SUPABASE_URL=<your-project-url>
VITE_SUPABASE_PUBLISHABLE_KEY=<anon-or-public-key>
```

4) **Run migrations** (from your project root):
```bash
supabase db reset   # or: supabase migration up
```

5) **Deploy functions**:
```bash
supabase functions deploy assessment-score
supabase functions deploy recs
```

6) **Seed data**:
```bash
node scripts/seed.mjs
```

7) **Wire the UI**:
- Replace localStorage usage in your assessment submit with `submitAssessment(answers)` from `src/services/assessment.ts`.
- On the dashboard, call `fetchRecs(user.id)` from `src/services/recs.ts` and render `<CareerCard />`.
- Use `CareerCanvas` page for deep-dive details.

---

## Notes
- Scores & rationale are **explainable** and safe defaults. Improve weights over time.
- Demand/salary are simple placeholders; integrate your real local data pipeline later.
- RLS only allows each user to read/write their own results & recs.

Happy building! 🚀
