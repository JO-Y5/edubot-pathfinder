
// src/pages/MappingTool.tsx
import React, { useEffect, useState } from "react";

export default function MappingTool() {
  const url = import.meta.env.VITE_SUPABASE_URL;
  const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

  const [courses, setCourses] = useState<any[]>([]);
  const [careers, setCareers] = useState<any[]>([]);
  const [selectedCourse, setSelectedCourse] = useState<string>("");
  const [selectedCareer, setSelectedCareer] = useState<string>("");

  useEffect(()=>{
    fetch(`${url}/rest/v1/provider_courses?select=id,title,skills&limit=200`, { headers:{ apikey:key, Authorization:`Bearer ${key}` }})
      .then(r=>r.json()).then(setCourses);
    fetch(`${url}/rest/v1/careers?select=id,title,skills`, { headers:{ apikey:key, Authorization:`Bearer ${key}` }})
      .then(r=>r.json()).then(setCareers);
  }, []);

  async function mapCourse() {
    const body = [{ provider_course_id: selectedCourse, career_id: selectedCareer, status: 'human_review' }];
    await fetch(`${url}/rest/v1/provider_mappings`, { method:"POST", headers:{ apikey:key, Authorization:`Bearer ${key}`, "Content-Type":"application/json" }, body: JSON.stringify(body) });
    // enqueue for review
    await fetch(`${url}/rest/v1/review_queue`, { method:"POST", headers:{ apikey:key, Authorization:`Bearer ${key}`, "Content-Type":"application/json" }, body: JSON.stringify([{ provider_mapping_id: body[0].provider_course_id }]) });
    alert('Added mapping to review queue');
  }

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-bold">Mapping Tool</h1>
      <div className="grid grid-cols-2 gap-3 mt-3">
        <select className="border px-2 py-1 rounded" value={selectedCourse} onChange={e=>setSelectedCourse(e.target.value)}>
          <option value="">Select Course</option>
          {courses.map(c=>(<option key={c.id} value={c.id}>{c.title}</option>))}
        </select>
        <select className="border px-2 py-1 rounded" value={selectedCareer} onChange={e=>setSelectedCareer(e.target.value)}>
          <option value="">Select Career</option>
          {careers.map(c=>(<option key={c.id} value={c.id}>{c.title}</option>))}
        </select>
      </div>
      <button onClick={mapCourse} className="mt-4 px-4 py-2 rounded bg-black text-white text-sm">Map & Enqueue Review</button>
    </div>
  );
}
