
import { useTranslation } from 'react-i18next';
export default function LegalTerms(){
  const { t } = useTranslation();
  return (
    <div className="max-w-3xl mx-auto p-6 prose">
      <h1>{t('terms_title')}</h1>
      <p>By using {t('appName')}, you agree to the following terms. باستخدامك للخدمة فإنك توافق على الشروط التالية.</p>
      <h2>Account</h2>
      <ul><li>No credential sharing.</li><li>Personal/Educational use.</li></ul>
      <h2>Content & IP</h2><p>...</p>
      <h2>Payments & Subscriptions</h2><p>...</p>
      <h2>Disclaimer</h2><p>...</p>
      <h2>Contact</h2><p>support@yourapp.com</p>
    </div>
  );
}
