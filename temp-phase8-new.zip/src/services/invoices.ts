
// src/services/invoices.ts
export async function listInvoices() {
  const url = import.meta.env.VITE_SUPABASE_URL;
  const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  const res = await fetch(`${url}/rest/v1/invoices?select=*`, { headers: { apikey:key, Authorization:`Bearer ${key}` }});
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function generateInvoicePdf(invoice: any) {
  try {
    const { jsPDF } = await import('jspdf');
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text('INVOICE', 14, 20);
    doc.setFontSize(11);
    doc.text(`Number: ${invoice.number}`, 14, 32);
    doc.text(`Amount: ${(invoice.amount_cents/100).toFixed(2)} ${invoice.currency}`, 14, 40);
    doc.text(`Status: ${invoice.status}`, 14, 48);
    doc.text(`Issued: ${new Date(invoice.issued_at).toLocaleString()}`, 14, 56);
    if (invoice.paid_at) doc.text(`Paid: ${new Date(invoice.paid_at).toLocaleString()}`, 14, 64);
    doc.save(`invoice_${invoice.number}.pdf`);
  } catch (e) {
    alert('Failed to export PDF');
  }
}
