
# Phase 10 – Content Partnerships & Quality + Human Review

## DB
- `providers`, `provider_courses`: تعريف مزودين ودوراتهم.
- `provider_mappings`: ربط الدورات بالمهن/المهارات (auto/human_review/approved/rejected).
- `content_quality`: درجة جودة المحتوى (freshness, reliability, popularity, boost).
- `review_queue`: قائمة انتظار للمراجعة البشرية.

## Edge
- `provider-sync`: إدخال CSV/JSON من الشريك → upsert دورات.
- `quality-score`: يحسب score ويخزن في `content_quality`.
- `review-assign` / `review-submit`: دورة المراجعة البشرية.

## Frontend
- `ProviderAdmin.tsx` لرفع مصادر الشركاء (CSV/JSON).
- `ReviewQueue.tsx` لإسناد ومراجعة العناصر.
- `MappingTool.tsx` أداة ربط سريعة (Course → Career) + إدراج في الطابور.

## تشغيل سريع
```bash
supabase migration up
supabase functions deploy provider-sync
supabase functions deploy quality-score
supabase functions deploy review-assign
supabase functions deploy review-submit
```

### تجربة الإدخال
- من `ProviderAdmin` ارفع `sources/provider_sample.csv` أو `sources/provider_sample.json`.
- بعد الإدخال، شغّل `quality-score` لتحديث درجات الجودة.

### ملاحظات
- التزام قانوني: استخدم مصادر شركاء/تصاريح واضحة، واتبع robots.txt لأي جمع بيانات.
- تقدر توسّع scoring بإضافة إشارات (completion rate، NPS، complaint rate).
- استخدم `provider_mappings.status` لإدارة دورة الموافقة ثم ادفع النتائج إلى واجهة الترشيحات.
