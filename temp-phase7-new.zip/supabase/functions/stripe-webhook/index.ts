
// supabase/functions/stripe-webhook/index.ts
// Handles Stripe webhook events to upsert subscriptions + entitlements.
// Set STRIPE_WEBHOOK_SECRET, STRIPE_SIGNING_SECRET (if needed), SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  try {
    const payload = await req.json();
    const type = payload?.type || "unknown";

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const headers = { apikey: SERVICE_ROLE, Authorization: `Bearer ${SERVICE_ROLE}`, "Content-Type":"application/json" };

    // Parse reference from checkout session / subscription metadata
    if (type === "checkout.session.completed" || type === "invoice.payment_succeeded" || type === "customer.subscription.updated") {
      const session = payload.data.object;
      const ref = (session.client_reference_id || session.metadata?.ref || "");
      let org_id = "", user_id = "";
      if (ref.startsWith("org:")) org_id = ref.split(":")[1];
      if (ref.startsWith("user:")) user_id = ref.split(":")[1];

      const price_id = session?.lines?.data?.[0]?.price?.id || session?.plan?.id || session?.items?.data?.[0]?.price?.id || "";
      const status = session?.status || session?.subscription?.status || "active";
      const period_end = session?.current_period_end ? new Date(session.current_period_end*1000).toISOString() : null;

      // Upsert subscription
      await fetch(`${SUPABASE_URL}/rest/v1/subscriptions`, {
        method: "POST",
        headers,
        body: JSON.stringify([{ org_id: org_id || null, user_id: user_id || null, provider: "stripe", status, price_id, current_period_end: period_end }]),
      });

      // Entitlements (simple): if org -> org plan 'org', else user -> 'pro'
      if (org_id) {
        await fetch(`${SUPABASE_URL}/rest/v1/organizations?id=eq.${org_id}`, {
          method: "PATCH", headers, body: JSON.stringify({ plan: "org" })
        });
      } else if (user_id) {
        // ensure user_profiles row exists and set plan=pro
        await fetch(`${SUPABASE_URL}/rest/v1/user_profiles`, {
          method: "POST", headers, body: JSON.stringify([{ id: user_id, plan: "pro" }]),
        });
      }
    }

    return new Response(JSON.stringify({ ok: true }), { headers: { ...CORS, "Content-Type":"application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 400, headers: { ...CORS, "Content-Type":"application/json" } });
  }
});
