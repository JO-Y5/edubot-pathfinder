
// supabase/functions/assessment-score/index.ts
// Deno edge function – computes RIASEC + Big5 and stores the result

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

type Answer = { id: string; value: number | string | string[] };

function normalize(n: number, max = 5) {
  const v = Math.max(0, Math.min(max, n));
  return +(v / max).toFixed(3);
}

function scoreVector(answers: Answer[], mapping: Record<string, string[]>, dims: string[]) {
  const acc: Record<string, number> = Object.fromEntries(dims.map(d => [d, 0]));
  const cnt: Record<string, number> = Object.fromEntries(dims.map(d => [d, 0]));
  for (const a of answers) {
    const dimsForQ = mapping[a.id] || [];
    const raw = typeof a.value === "number" ? a.value : 1;
    for (const d of dimsForQ) {
      acc[d] += raw;
      cnt[d] += 1;
    }
  }
  const vec: Record<string, number> = {};
  for (const d of dims) {
    vec[d] = cnt[d] ? normalize(acc[d] / cnt[d]) : 0;
  }
  return vec;
}

// Light mappings – replace with your richer mapping later
const RIASEC_DIMS = ["R","I","A","S","E","C"];
const BIG5_DIMS = ["O","C","E","A","N"];

// Example minimal mapping (id prefixes). Replace with data from your questionnaire.
function mapByPrefix(answers: Answer[], prefixMap: Record<string, string[]>, dims: string[]) {
  const mapping: Record<string, string[]> = {};
  for (const a of answers) {
    const match = Object.entries(prefixMap).find(([p]) => a.id.startsWith(p));
    if (match) mapping[a.id] = match[1];
  }
  return scoreVector(answers, mapping, dims);
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  try {
    const { answers, user_id } = await req.json();
    if (!user_id) throw new Error("Missing user_id");
    if (!Array.isArray(answers)) throw new Error("answers must be an array");

    const riasec = mapByPrefix(answers, {
      "r_": ["R"],
      "i_": ["I"],
      "a_": ["A"],
      "s_": ["S"],
      "e_": ["E"],
      "c_": ["C"],
    }, RIASEC_DIMS);

    const big5 = mapByPrefix(answers, {
      "o_": ["O"],
      "c5_": ["C"],
      "e5_": ["E"],
      "a5_": ["A"],
      "n5_": ["N"],
    }, BIG5_DIMS);

    const confidence = 0.8;

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const ins = await fetch(`${SUPABASE_URL}/rest/v1/results`, {
      method: "POST",
      headers: {
        apikey: SERVICE_ROLE,
        Authorization: `Bearer ${SERVICE_ROLE}`,
        "Content-Type": "application/json",
        Prefer: "return=representation",
      },
      body: JSON.stringify({ user_id, riasec, big5, confidence })
    });
    if (!ins.ok) throw new Error(await ins.text());

    return new Response(JSON.stringify({ riasec, big5, confidence }), {
      headers: { ...CORS, "Content-Type": "application/json" }
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: `${e}` }), {
      status: 400,
      headers: { ...CORS, "Content-Type": "application/json" }
    });
  }
});
