
// supabase/functions/billing-checkout/index.ts
// Creates a Stripe checkout session for personal or org subscription.
// Env required (Edge secrets): STRIPE_SECRET_KEY, STRIPE_PRICE_PRO, STRIPE_PRICE_ORG, SITE_URL

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

type Req = { mode?: 'personal'|'org'; org_id?: string; user_id: string };

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  try {
    const { mode='personal', org_id, user_id } = await req.json() as Req;
    if (!user_id) throw new Error("user_id required");
    if (mode === 'org' && !org_id) throw new Error("org_id required for org mode");

    const STRIPE_SECRET_KEY = Deno.env.get("STRIPE_SECRET_KEY")!;
    const PRICE_PRO = Deno.env.get("STRIPE_PRICE_PRO")!;
    const PRICE_ORG = Deno.env.get("STRIPE_PRICE_ORG")!;
    const SITE_URL = Deno.env.get("SITE_URL") || "http://localhost:5173";

    const price = mode === 'org' ? PRICE_ORG : PRICE_PRO;
    const body = {
      mode: "subscription",
      line_items: [{ price, quantity: 1 }],
      success_url: `${SITE_URL}/billing/success`,
      cancel_url: `${SITE_URL}/billing/cancel`,
      client_reference_id: mode === 'org' ? `org:${org_id}` : `user:${user_id}`,
      metadata: { user_id, org_id: org_id || "", mode }
    };

    const res = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${STRIPE_SECRET_KEY}`,
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: new URLSearchParams({ payment_method_types: "card", ...toForm(body) })
    });

    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();

    return new Response(JSON.stringify({ url: data.url }), { headers: { ...CORS, "Content-Type":"application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 400, headers: { ...CORS, "Content-Type":"application/json" } });
  }
});

function toForm(obj: any, prefix="") {
  const out: Record<string,string> = {};
  for (const [k,v] of Object.entries(obj)) {
    const key = prefix ? `${prefix}[${k}]` : k;
    if (Array.isArray(v)) v.forEach((item, i)=>Object.assign(out, toForm(item, `${key}[${i}]`)));
    else if (v && typeof v === 'object') Object.assign(out, toForm(v, key));
    else out[key] = String(v);
  }
  return out;
}
