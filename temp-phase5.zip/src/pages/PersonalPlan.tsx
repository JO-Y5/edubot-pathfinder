
// src/pages/PersonalPlan.tsx
import React, { useEffect, useState } from "react";
import { listPlan, updatePlanStatus } from "@/services/plan";
import { sendEvent } from "@/services/events";
import { useAuth } from "@/contexts/AuthContext";
import { exportPlanPdf } from "@/services/pdfExport";

type Item = { id:string; item_type:'career'|'course'; item_id:string; status:'todo'|'in_progress'|'done' };

export default function PersonalPlan() {
  const { user } = useAuth();
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    if (!user) return;
    setLoading(true);
    const rows = await listPlan(user.id);
    setItems(rows);
    setLoading(false);
  }

  useEffect(()=>{ load(); }, [user]);

  async function onStatusChange(id:string, status:Item['status']) {
    await updatePlanStatus(id, status);
    sendEvent(user!.id, 'plan_status_change', { id, status });
    load();
  }

  function onExport() { exportPlanPdf(items); }

  if (loading) return <div className="p-6">Loading...</div>;

  return (
    <div className="max-w-3xl mx-auto p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">خطتي الشخصية</h1>
        <button onClick={onExport} className="px-3 py-2 rounded bg-black text-white text-sm">Export PDF</button>
      </div>
      <table className="w-full mt-4 text-sm">
        <thead>
          <tr className="text-left border-b">
            <th className="py-2">Type</th>
            <th>Item</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {items.map(it=>(
            <tr key={it.id} className="border-b">
              <td className="py-2">{it.item_type}</td>
              <td>{it.item_id}</td>
              <td>
                <select value={it.status} onChange={e=>onStatusChange(it.id, e.target.value as any)} className="border rounded px-2 py-1">
                  <option value="todo">To do</option>
                  <option value="in_progress">In progress</option>
                  <option value="done">Done</option>
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
