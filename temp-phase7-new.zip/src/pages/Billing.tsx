
// src/pages/Billing.tsx
import React, { useState } from "react";
import { useOrg } from "@/contexts/OrgContext";

async function createSession(payload:any) {
  const EDGE = import.meta.env.VITE_EDGE_URL || ""; // set EDGE if different
  const res = await fetch(`${EDGE}/billing-checkout`, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(payload) });
  const data = await res.json();
  if (data?.url) location.href = data.url;
  else alert(data?.error || "Error creating session");
}

export default function Billing() {
  const { org } = useOrg();
  const [mode, setMode] = useState<'personal'|'org'>(org ? 'org':'personal');

  function onCheckout() {
    if (mode === 'org' && !org) return alert("اختر منظمة أولاً");
    createSession({ mode, org_id: org?.id, user_id: (window as any).user?.id });
  }

  return (
    <div className="max-w-xl mx-auto p-6">
      <h1 className="text-2xl font-bold">الترقية والدفع</h1>
      <div className="mt-4 p-4 border rounded-2xl">
        <label className="flex items-center gap-2">
          <input type="radio" name="mode" checked={mode==='personal'} onChange={()=>setMode('personal')} />
          <span>شخصي (Pro)</span>
        </label>
        <label className="flex items-center gap-2 mt-2">
          <input type="radio" name="mode" checked={mode==='org'} onChange={()=>setMode('org')} />
          <span>منظمة (Org plan)</span>
        </label>
        <button onClick={onCheckout} className="mt-4 px-4 py-2 rounded bg-black text-white text-sm">Checkout</button>
      </div>
    </div>
  );
}
