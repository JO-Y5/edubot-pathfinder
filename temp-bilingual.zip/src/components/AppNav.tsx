
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

export default function AppNav(){
  const { i18n, t } = useTranslation();
  const toggleLang = () => i18n.changeLanguage(i18n.language === 'ar' ? 'en' : 'ar');
  return (
    <header className="w-full border-b">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="font-extrabold text-lg">{t('appName')}</Link>
        <nav className="flex items-center gap-4 text-sm">
          <Link to="/pricing">{t('nav_pricing')}</Link>
          <Link to="/help">{t('nav_help')}</Link>
          <Link to="/legal/terms">{t('nav_terms')}</Link>
          <Link to="/legal/privacy">{t('nav_privacy')}</Link>
          <Link to="/analytics" className="hidden md:inline">{t('nav_analytics')}</Link>
          <Link to="/providers" className="hidden md:inline">{t('nav_providers')}</Link>
          <Link to="/reviews" className="hidden md:inline">{t('nav_reviews')}</Link>
          <Link to="/mapping" className="hidden md:inline">{t('nav_mapping')}</Link>
          <button onClick={toggleLang} className="ml-2 border rounded px-2 py-1">{i18n.language === 'ar' ? 'EN' : 'AR'}</button>
        </nav>
      </div>
    </header>
  );
}
