
// src/services/feedback.ts
export async function sendFeedback(userId: string, careerId: string, label: 'like'|'dislike') {
  const url = `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/feedback`;
  const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      apikey: key as string,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      Prefer: "resolution=merge-duplicates"
    },
    body: JSON.stringify([{ user_id: userId, career_id: careerId, label }])
  });
  if (!res.ok) throw new Error(await res.text());
  return res;
}

export async function saveToPlan(userId: string, itemType:'career'|'course', itemId: string) {
  const url = `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/plan_items`;
  const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      apikey: key as string,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      Prefer: "resolution=merge-duplicates"
    },
    body: JSON.stringify([{ user_id: userId, item_type: itemType, item_id: itemId }])
  });
  if (!res.ok) throw new Error(await res.text());
  return res;
}
