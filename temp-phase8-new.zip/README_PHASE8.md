
# Phase 8 – Advanced Admin, Usage, Groups/Classes, Invoices PDF, Fine-Grained Permissions

## DB
- `groups`, `class_enrollments`: تنظيم الطلبة في مجموعات/صفوف مع أدوار (student/coach/ta).
- `permissions`: صلاحيات دقيقة (view_results, export_pdf, manage_users...).
- `invoices`: تخزين فواتير (Sync مع Stripe لاحقًا أو إدخال يدوي).

## Edge
- `usage-report`: تجميع استخدام آخر 30 يوم (Assessments, clicks, saves, completes) على مستوى Org/Group.

## Frontend
- `AdminAdvanced.tsx`: شاشة إدارة متقدمة + فلترة حسب Group.
- `Invoices.tsx` + `invoices.ts`: عرض وتصدير PDF (jsPDF).
- `usePerm.ts`: Hook بسيط للتحقق من الإذن في الواجهة.

## تركيب سريع
```bash
supabase migration up
supabase functions deploy usage-report
```

### Routing
```tsx
// <Route path="/admin/advanced" element={<AdminAdvanced/>} />
// <Route path="/billing/invoices" element={<Invoices/>} />
```

### ملاحظات
- اربط توليد `invoices` مع Stripe Webhook (Phase 7) لو حبيت تفاوتر تلقائيًا (insert row عند كل دفع).
- تقدر توسّع `permissions` لإضافة Feature flags على مستوى org/group/user.
- استخدم `class_enrollments` لعرض لوحات متابعة لكل صف/مجموعة.
