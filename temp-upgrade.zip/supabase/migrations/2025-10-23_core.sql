
-- 2025-10-23: Core tables + RLS

create table if not exists public.careers (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  summary text,
  skills text[] not null default '{}',
  demand int not null default 50,
  salary_egp jsonb,
  riasec_proto jsonb,
  created_at timestamptz default now()
);

create table if not exists public.courses (
  id uuid primary key default gen_random_uuid(),
  platform text not null,
  title text not null,
  url text not null,
  hours int,
  cost int,
  lang text,
  skills text[] not null default '{}',
  created_at timestamptz default now()
);

create table if not exists public.results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  riasec jsonb,
  big5 jsonb,
  confidence numeric default 0.8,
  created_at timestamptz default now()
);

create table if not exists public.recs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  target_type text not null check (target_type in ('career','course')),
  target_id uuid not null,
  score numeric not null,
  rationale text,
  created_at timestamptz default now()
);

-- Indexes
create index if not exists idx_careers_slug on public.careers(slug);
create index if not exists idx_recs_user on public.recs(user_id);
create index if not exists idx_results_user on public.results(user_id);

-- RLS
alter table public.results enable row level security;
alter table public.recs enable row level security;

create policy if not exists "results_select_own"
on public.results for select to authenticated
using (auth.uid() = user_id);

create policy if not exists "results_insert_own"
on public.results for insert to authenticated
with check (auth.uid() = user_id);

create policy if not exists "recs_select_own"
on public.recs for select to authenticated
using (auth.uid() = user_id);

create policy if not exists "recs_insert_own"
on public.recs for insert to authenticated
with check (auth.uid() = user_id);
