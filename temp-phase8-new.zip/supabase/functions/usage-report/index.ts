
// supabase/functions/usage-report/index.ts
// Returns usage aggregates for an org or group: users count, assessments, rec clicks, plan adds, completions (last 30d)
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  try {
    const { org_id, group_id } = await req.json();

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const headers = { apikey: SERVICE_ROLE, Authorization: `Bearer ${SERVICE_ROLE}` };

    const since = new Date(Date.now() - 30*24*60*60*1000).toISOString();

    // Users in scope
    let users: string[] = [];
    if (group_id) {
      const en = await fetch(`${SUPABASE_URL}/rest/v1/class_enrollments?group_id=eq.${group_id}&select=user_id`, { headers });
      users = (await en.json()).map((r:any)=>r.user_id);
    } else if (org_id) {
      const mem = await fetch(`${SUPABASE_URL}/rest/v1/org_memberships?org_id=eq.${org_id}&select=user_id`, { headers });
      users = (await mem.json()).map((r:any)=>r.user_id);
    }

    const userList = users.length ? `in.(${users.join(",")})` : "is.not.null";

    const [resAssess, resEvents] = await Promise.all([
      fetch(`${SUPABASE_URL}/rest/v1/results?user_id=${userList}&created_at=gte.${since}&select=count`, { headers }),
      fetch(`${SUPABASE_URL}/rest/v1/events?user_id=${userList}&created_at=gte.${since}&select=name,user_id`, { headers })
    ]);

    const assessments = +(await resAssess.headers.get("content-range") || "0/0").split("/").pop()! || 0;
    const events = await resEvents.json();
    let clicks=0, saves=0, completes=0;
    for (const e of events) {
      if (e.name === 'rec_clicked') clicks++;
      if (e.name === 'plan_added') saves++;
      if (e.name === 'course_completed') completes++;
    }

    return new Response(JSON.stringify({ users: users.length, last30d: { assessments, clicks, saves, completes } }), { headers: { ...CORS, "Content-Type":"application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 400, headers: { ...CORS, "Content-Type":"application/json" } });
  }
});
