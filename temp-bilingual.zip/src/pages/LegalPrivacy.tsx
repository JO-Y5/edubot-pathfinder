
import { useTranslation } from 'react-i18next';
export default function LegalPrivacy(){
  const { t } = useTranslation();
  return (
    <div className="max-w-3xl mx-auto p-6 prose">
      <h1>{t('privacy_title')}</h1>
      <p>We respect your privacy. نحن نحترم خصوصيتك.</p>
      <h2>Data collected</h2><p>Name, Email, Assessment results...</p>
      <h2>Why</h2><p>Personalization & product improvement.</p>
      <h2>Sharing</h2><p>Payments (Stripe), Analytics (optional)...</p>
      <h2>Your rights</h2><p>Access, correction, deletion.</p>
      <h2>Contact</h2><p>privacy@yourapp.com</p>
    </div>
  );
}
