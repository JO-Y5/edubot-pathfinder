
// src/pages/AnalyticsDashboard.tsx
import React, { useEffect, useState } from "react";

type Pt = { day:string; value:number; variant_key?:string };
type Coh = { cohort_date:string; day_n:number; users:number; retained:number };
type Fun = { day:string; step1:number; step2:number; step3:number };

export default function AnalyticsDashboard() {
  const EDGE = import.meta.env.VITE_EDGE_URL;
  const [metric, setMetric] = useState("active_users");
  const [series, setSeries] = useState<Pt[]>([]);
  const [cohorts, setCohorts] = useState<Coh[]>([]);
  const [funnel, setFunnel] = useState<Fun[]>([]);

  async function load() {
    const res = await fetch(`${EDGE}/metrics-report?metric=${metric}`);
    const data = await res.json();
    setSeries(data.metrics || []);
    setCohorts(data.cohorts || []);
    setFunnel(data.funnel || []);
  }

  useEffect(()=>{ load(); }, [metric]);

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h1 className="text-2xl font-bold">لوحة التحليلات</h1>
      <div className="mt-3">
        <select value={metric} onChange={e=>setMetric(e.target.value)} className="border rounded px-2 py-1">
          <option value="active_users">Active Users</option>
          <option value="assessment_starts">Assessment Starts</option>
          <option value="assessment_completes">Assessment Completes</option>
          <option value="rec_clicks">Rec Clicks</option>
          <option value="plan_adds">Plan Adds</option>
        </select>
      </div>

      <section className="mt-6">
        <h2 className="font-semibold">Time Series</h2>
        <div className="text-xs text-gray-600 mb-2">قيم يومية للمؤشر المختار</div>
        <LineChart data={series} />
      </section>

      <section className="mt-6">
        <h2 className="font-semibold">Cohort Retention (Day 0..30)</h2>
        <RetentionTable rows={cohorts} />
      </section>

      <section className="mt-6">
        <h2 className="font-semibold">Funnel (3 خطوات)</h2>
        <FunnelTable rows={funnel} />
      </section>
    </div>
  );
}

function LineChart({ data }: { data: Pt[] }) {
  return (
    <div className="border rounded p-3 overflow-x-auto">
      <table className="w-full text-xs">
        <thead><tr><th className="text-left">Day</th><th>Value</th></tr></thead>
        <tbody>
          {data.map((p,i)=>(<tr key={i} className="border-t"><td className="py-1">{p.day}</td><td className="text-center">{p.value}</td></tr>))}
        </tbody>
      </table>
    </div>
  );
}

function RetentionTable({ rows }: { rows: Coh[] }) {
  // group by cohort_date
  const byCoh: Record<string, Coh[]> = {};
  rows.forEach(r => { byCoh[r.cohort_date] = byCoh[r.cohort_date] || []; byCoh[r.cohort_date].push(r); });
  return (
    <div className="border rounded p-3 overflow-x-auto">
      <table className="text-xs">
        <thead><tr><th>Cohort</th>{Array.from({length:31}).map((_,i)=><th key={i}>D{i}</th>)}</tr></thead>
        <tbody>
          {Object.entries(byCoh).map(([coh, arr])=>{
            const map: Record<number, number> = {};
            arr.forEach(r => map[r.day_n] = Math.round((r.retained / Math.max(1,r.users))*100));
            return (
              <tr key={coh} className="border-t">
                <td className="py-1 pr-2 whitespace-nowrap">{coh}</td>
                {Array.from({length:31}).map((_,i)=><td key={i} className="text-center">{map[i]||0}%</td>)}
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  );
}

function FunnelTable({ rows }: { rows: Fun[] }) {
  return (
    <div className="border rounded p-3 overflow-x-auto">
      <table className="text-xs">
        <thead><tr><th>Day</th><th>Step1</th><th>Step2</th><th>Step3</th></tr></thead>
        <tbody>
          {rows.map((r,i)=>(<tr key={i} className="border-t"><td className="py-1">{r.day}</td><td className="text-center">{r.step1}</td><td className="text-center">{r.step2}</td><td className="text-center">{r.step3}</td></tr>))}
        </tbody>
      </table>
    </div>
  );
}
