
// src/pages/Onboarding.tsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useI18n } from "@/i18n";
import LangSwitcher from "@/components/LangSwitcher";
import { track } from "@/lib/analytics";

export default function Onboarding() {
  const { t } = useI18n();
  const [step, setStep] = useState(1);
  const [goal, setGoal] = useState<'major'|'career'|'courses'|null>(null);
  const [consent, setConsent] = useState(false);
  const nav = useNavigate();

  function next() { setStep(s => Math.min(3, s+1)); }
  function back() { setStep(s => Math.max(1, s-1)); }

  return (
    <div className="max-w-xl mx-auto p-6">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold">{t('welcome_title')}</h1>
        <LangSwitcher />
      </div>
      <p className="text-gray-600">{t('welcome_sub')}</p>

      {/* Steps */}
      <div className="mt-6">
        {step === 1 && (
          <section className="p-4 rounded-2xl border">
            <h2 className="font-semibold mb-2">{t('goal_title')}</h2>
            <div className="grid gap-2">
              <label className={`border rounded p-3 cursor-pointer ${goal==='major'?'bg-gray-50':''}`}>
                <input type="radio" name="goal" className="mr-2" onChange={()=>setGoal('major')} /> {t('goal_major')}
              </label>
              <label className={`border rounded p-3 cursor-pointer ${goal==='career'?'bg-gray-50':''}`}>
                <input type="radio" name="goal" className="mr-2" onChange={()=>setGoal('career')} /> {t('goal_career')}
              </label>
              <label className={`border rounded p-3 cursor-pointer ${goal==='courses'?'bg-gray-50':''}`}>
                <input type="radio" name="goal" className="mr-2" onChange={()=>setGoal('courses')} /> {t('goal_courses')}
              </label>
            </div>
          </section>
        )}

        {step === 2 && (
          <section className="p-4 rounded-2xl border">
            <h2 className="font-semibold mb-2">{t('consent_title')}</h2>
            <p className="text-sm text-gray-700">{t('consent_text')}</p>
            <label className="flex items-center gap-2 mt-3">
              <input type="checkbox" checked={consent} onChange={e=>setConsent(e.target.checked)} />
              <span className="text-sm">I agree</span>
            </label>
          </section>
        )}

        {step === 3 && (
          <section className="p-4 rounded-2xl border text-center">
            <h2 className="font-semibold mb-2">{t('assessment_ready')}</h2>
            <button
              onClick={()=>{ track('assessment_start', { goal }); nav('/assessment'); }}
              className="px-4 py-2 rounded-lg bg-black text-white text-sm"
            >
              {t('start_assessment')}
            </button>
          </section>
        )}
      </div>

      {/* Nav */}
      <div className="mt-6 flex justify-between">
        <button onClick={back} disabled={step===1} className="px-4 py-2 rounded-lg border text-sm disabled:opacity-50">{t('back')}</button>
        <button
          onClick={next}
          disabled={(step===1 && !goal) || (step===2 && !consent)}
          className="px-4 py-2 rounded-lg bg-black text-white text-sm disabled:opacity-50"
        >
          {step<3 ? t('next') : t('finish')}
        </button>
      </div>
    </div>
  );
}
