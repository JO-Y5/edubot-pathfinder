
// src/lib/analytics.ts
import posthog from 'posthog-js';

const key = import.meta.env.VITE_POSTHOG_KEY;
const host = import.meta.env.VITE_POSTHOG_HOST || 'https://app.posthog.com';

export function initAnalytics() {
  if (!key) return;
  posthog.init(key, { api_host: host, capture_pageview: true });
}

export function identify(userId?: string, props?: Record<string, any>) {
  if (!key || !userId) return;
  posthog.identify(userId, props);
}

export function track(event: string, props?: Record<string, any>) {
  if (!key) return;
  posthog.capture(event, props);
}
