
// supabase/functions/experiment-assign/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function hashStr(str:string){
  let h = 2166136261;
  for (let i=0;i<str.length;i++) { h ^= str.charCodeAt(i); h += (h<<1)+(h<<4)+(h<<7)+(h<<8)+(h<<24); }
  return (h>>>0);
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  try {
    const { user_id, experiment_key } = await req.json();
    if (!user_id || !experiment_key) throw new Error("user_id and experiment_key required");

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const headers = { apikey: SERVICE_ROLE, Authorization:`Bearer ${SERVICE_ROLE}` };

    // fetch experiment & variants
    const eRes = await fetch(`${SUPABASE_URL}/rest/v1/experiments?select=id,key,status&key=eq.${experiment_key}&limit=1`, { headers });
    const exp = (await eRes.json())?.[0];
    if (!exp || exp.status !== 'running') return new Response(JSON.stringify({ variant_key: 'control' }), { headers: { ...CORS, "Content-Type":"application/json" } });

    const vRes = await fetch(`${SUPABASE_URL}/rest/v1/variants?select=key,weight&experiment_id=eq.${exp.id}`, { headers });
    const variants = await vRes.json();

    const total = variants.reduce((s:any,v:any)=>s+Number(v.weight||0), 0) || 100;
    const rnd = hashStr(user_id + ":" + experiment_key) % total;
    let acc = 0, chosen = variants[0]?.key || 'A';
    for (const v of variants) { acc += Number(v.weight||0); if (rnd < acc) { chosen = v.key; break; } }

    // upsert assignment
    const up = await fetch(`${SUPABASE_URL}/rest/v1/assignments`, {
      method:"POST", headers: { ...headers, "Content-Type":"application/json", Prefer:"resolution=merge-duplicates" },
      body: JSON.stringify([{ user_id, experiment_id: exp.id, variant_key: chosen }])
    });
    if (!up.ok) throw new Error(await up.text());

    return new Response(JSON.stringify({ variant_key: chosen }), { headers: { ...CORS, "Content-Type":"application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 400, headers: { ...CORS, "Content-Type":"application/json" } });
  }
});
