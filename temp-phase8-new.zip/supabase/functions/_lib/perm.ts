
// supabase/functions/_lib/perm.ts
export async function hasPermission(supabaseUrl: string, key: string, userId: string, check: { org_id?:string; group_id?:string; permission:string }) {
  const headers = { apikey:key, Authorization:`Bearer ${key}` };
  const q: string[] = [];
  if (check.org_id) q.push(`org_id=eq.${check.org_id}`);
  if (check.group_id) q.push(`group_id=eq.${check.group_id}`);
  q.push(`permission=eq.${check.permission}`);
  q.push(`user_id=eq.${userId}`);
  const url = `${supabaseUrl}/rest/v1/permissions?select=id&` + q.join("&");
  const res = await fetch(url, { headers });
  const rows = await res.json();
  return rows?.length > 0;
}
