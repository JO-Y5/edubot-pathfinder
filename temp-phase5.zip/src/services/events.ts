
// src/services/events.ts
export async function sendEvent(userId: string, name: string, props: Record<string, any> = {}) {
  const url = `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/events`;
  const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      apikey: key as string,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify([{ user_id: userId, name, props }])
  });
  return res.ok;
}
