
-- 2025-10-23_phase10: providers + provider_courses + mappings + quality + review queue

create table if not exists public.providers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  contact_email text,
  website text,
  active boolean default true,
  created_at timestamptz default now()
);

create table if not exists public.provider_courses (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid not null references public.providers(id) on delete cascade,
  ext_id text not null,                     -- provider's external id
  title text not null,
  url text,
  language text default 'ar',
  level text,                               -- beginner/intermediate/advanced
  skills text[] default '{}',
  hours int,
  price_cents int,
  currency text default 'EGP',
  rating numeric,
  raw jsonb,
  created_at timestamptz default now(),
  unique(provider_id, ext_id)
);

create table if not exists public.provider_mappings (
  id uuid primary key default gen_random_uuid(),
  provider_course_id uuid not null references public.provider_courses(id) on delete cascade,
  career_id uuid references public.careers(id) on delete set null,
  skill_tags text[] default '{}',
  status text not null default 'auto' check (status in ('auto','human_review','approved','rejected')),
  notes text,
  created_at timestamptz default now()
);

create table if not exists public.content_quality (
  id uuid primary key default gen_random_uuid(),
  provider_course_id uuid not null references public.provider_courses(id) on delete cascade,
  score numeric not null default 0,           -- 0..1
  freshness int,                              -- days since last update
  provider_reliability numeric default 0.5,   -- 0..1
  popularity numeric default 0,               -- normalized enrollment/reviews 0..1
  manual_boost numeric default 0,             -- -1..+1 (admin tweak)
  created_at timestamptz default now()
);

create table if not exists public.review_queue (
  id uuid primary key default gen_random_uuid(),
  provider_mapping_id uuid not null references public.provider_mappings(id) on delete cascade,
  assigned_to uuid references auth.users(id) on delete set null,
  state text not null default 'todo' check (state in ('todo','in_progress','done')),
  guideline_version text default 'v1',
  created_at timestamptz default now()
);

-- RLS enable
alter table public.providers enable row level security;
alter table public.provider_courses enable row level security;
alter table public.provider_mappings enable row level security;
alter table public.content_quality enable row level security;
alter table public.review_queue enable row level security;

-- Read policies (authenticated)
create policy if not exists "providers_read" on public.providers for select to authenticated using (true);
create policy if not exists "provider_courses_read" on public.provider_courses for select to authenticated using (true);
create policy if not exists "provider_mappings_read" on public.provider_mappings for select to authenticated using (true);
create policy if not exists "content_quality_read" on public.content_quality for select to authenticated using (true);
create policy if not exists "review_queue_read" on public.review_queue for select to authenticated using (assigned_to = auth.uid() or assigned_to is null);

-- Write via service role; (optional) add admin policies later
