
// src/services/plan.ts
export async function listPlan(userId: string) {
  const url = `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/plan_items?user_id=eq.${userId}&select=*`;
  const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  const res = await fetch(url, { headers: { apikey: key as string, Authorization: `Bearer ${key}` } });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function updatePlanStatus(id: string, status: 'todo'|'in_progress'|'done') {
  const url = `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/plan_items?id=eq.${id}`;
  const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  const res = await fetch(url, {
    method: "PATCH",
    headers: {
      apikey: key as string,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ status })
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}
