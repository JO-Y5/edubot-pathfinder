
# Billing ENV (Edge Secrets)
STRIPE_SECRET_KEY=
STRIPE_PRICE_PRO=price_xxx
STRIPE_PRICE_ORG=price_yyy
SITE_URL=https://your-frontend.example

# Frontend ENV
VITE_EDGE_URL=https://<supabase-project>.functions.supabase.co
