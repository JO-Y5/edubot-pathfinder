
// supabase/functions/_lib/rate_limit.ts
const buckets = new Map<string, { tokens: number; ts: number }>();

export function allow(key: string, limit = 60, windowMs = 60_000) {
  const now = Date.now();
  const b = buckets.get(key) || { tokens: limit, ts: now };
  const elapsed = now - b.ts;
  const refill = Math.floor(elapsed / windowMs) * limit;
  let tokens = Math.min(limit, b.tokens + (refill > 0 ? refill : 0));
  const allowed = tokens > 0;
  tokens = allowed ? tokens - 1 : tokens;
  buckets.set(key, { tokens, ts: now });
  return allowed;
}
