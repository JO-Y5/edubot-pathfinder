
// supabase/functions/assessment-cat/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

type Answer = { id:string; value:number };

function mean(arr:number[]) { return arr.length? arr.reduce((a,b)=>a+b,0)/arr.length : 0; }
function norm(v:number, max=5){ const x=Math.max(0,Math.min(max,v)); return +(x/max).toFixed(3); }

async function loadBank() {
  const res = await fetch(new URL("./bank.json", import.meta.url));
  return res.json();
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  try {
    const { user_id, answers=[], maxQuestions=30, stopAt=0.9 } = await req.json();
    if (!user_id) throw new Error("Missing user_id");

    const bank = await loadBank();

    const map = new Map<string, number[]>();
    for (const a of answers as Answer[]) {
      const k = a.id.split("_")[0].toUpperCase();
      if (!map.has(k)) map.set(k, []);
      map.get(k)!.push(typeof a.value === "number" ? a.value : 0);
    }
    const dims = ["R","I","A","S","E","C"];
    const riasec:any = {};
    for (const d of dims) riasec[d] = norm(mean(map.get(d)||[]));

    const big5dims = ["O","C","E","A","N"];
    const big5:any = {};
    for (const d of big5dims) big5[d] = norm(mean(map.get(d)||[]));

    const answered = (answers as Answer[]).length;
    const proportion = Math.min(1, answered / maxQuestions);
    let coverage = 0;
    dims.forEach(d => coverage += (map.get(d)?.length ? 1 : 0));
    coverage = coverage / dims.length;
    const confidence = +(0.5*proportion + 0.5*coverage).toFixed(2);
    const done = confidence >= stopAt || answered >= maxQuestions;

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    if (done) {
      await fetch(`${SUPABASE_URL}/rest/v1/results`, {
        method: "POST",
        headers: { apikey: SERVICE_ROLE, Authorization:`Bearer ${SERVICE_ROLE}`, "Content-Type":"application/json" },
        body: JSON.stringify({ user_id, riasec, big5, confidence })
      });
    }

    return new Response(JSON.stringify({ riasec, big5, confidence, done }), { headers: { ...CORS, "Content-Type":"application/json" }});
  } catch (e) {
    return new Response(JSON.stringify({ error: `${e}` }), { status: 400, headers: { ...CORS, "Content-Type":"application/json" }});
  }
});
