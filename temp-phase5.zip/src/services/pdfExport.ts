
// src/services/pdfExport.ts
export async function exportPlanPdf(items: any[]) {
  try {
    const { jsPDF } = await import('jspdf');
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text('Personal Plan', 14, 20);
    doc.setFontSize(11);
    let y = 30;
    items.forEach((it: any, idx: number) => {
      const line = `${idx+1}. [${it.item_type}] ${it.item_id} — ${it.status}`;
      doc.text(line, 14, y);
      y += 8;
      if (y > 280) { doc.addPage(); y = 20; }
    });
    doc.save('personal-plan.pdf');
  } catch (e) {
    window.print();
  }
}
