
-- 2025-10-23_phase6: user_profiles (plan, role) + RLS

create table if not exists public.user_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  plan text not null default 'basic' check (plan in ('basic','pro')),
  role text not null default 'student' check (role in ('student','coach','admin')),
  created_at timestamptz default now()
);

alter table public.user_profiles enable row level security;

create policy if not exists "profiles_self_select"
on public.user_profiles for select
to authenticated
using (auth.uid() = id or role in ('coach','admin'));

create policy if not exists "profiles_self_upsert"
on public.user_profiles for insert
to authenticated
with check (auth.uid() = id);

create policy if not exists "profiles_self_update"
on public.user_profiles for update
to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);
