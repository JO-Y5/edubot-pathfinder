
// src/components/CareerCard.tsx (enhanced with like/dislike & save)
import React from "react";
import { track } from "@/lib/analytics";

type Props = {
  id: string;
  title: string;
  score: number;
  rationale: string;
  skills?: string[];
  demand?: number;
  salary_egp?: { p50?: number; p90?: number };
  onOpen?: () => void;
  onLike?: () => void;
  onDislike?: () => void;
  onSave?: () => void;
};

export default function CareerCard({ id, title, score, rationale, skills=[], demand=50, salary_egp, onOpen, onLike, onDislike, onSave }: Props) {
  const percent = Math.round(score * 100);
  return (
    <div className="rounded-2xl border p-4 shadow-sm hover:shadow-md transition">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">{title}</h3>
        <span className="text-sm px-2 py-1 rounded bg-gray-100">{percent}% fit</span>
      </div>
      <p className="mt-2 text-sm text-gray-600">{rationale}</p>
      <div className="mt-3 text-sm">
        <div className="flex gap-2 flex-wrap">
          {skills.slice(0,6).map((s) => (
            <span key={s} className="px-2 py-1 bg-gray-50 rounded border text-xs">{s}</span>
          ))}
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-gray-700">
          <div>Demand: <strong>{demand}</strong></div>
          <div>Median salary: <strong>{salary_egp?.p50 ? `${salary_egp.p50.toLocaleString()} EGP` : "—"}</strong></div>
        </div>
      </div>
      <div className="mt-4 flex items-center gap-2">
        <button onClick={()=>{ onOpen?.(); track('career_open', { id, title }); }} className="px-3 py-2 rounded-lg bg-black text-white text-sm">View</button>
        <button onClick={()=>{ onSave?.(); track('plan_add', { id, title }); }} className="px-3 py-2 rounded-lg bg-gray-900/80 text-white text-sm">Save</button>
        <button onClick={()=>{ onLike?.(); track('career_like', { id, title }); }} className="px-2 py-1 rounded border text-xs">👍</button>
        <button onClick={()=>{ onDislike?.(); track('career_dislike', { id, title }); }} className="px-2 py-1 rounded border text-xs">👎</button>
      </div>
    </div>
  );
}
