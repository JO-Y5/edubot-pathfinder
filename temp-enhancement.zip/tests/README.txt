
// Add to package.json:
// "devDependencies": { "vitest": "^2.0.0", "ts-node": "^10.9.2" },
// "scripts": { "test": "vitest run" }
