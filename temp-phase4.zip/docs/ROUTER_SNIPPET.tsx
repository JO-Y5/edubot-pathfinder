
// Add to your router config
// import Onboarding from "@/pages/Onboarding";
// import AssessmentResult from "@/pages/AssessmentResult";
// import CareerCanvas from "@/pages/CareerCanvas";

// <Route path="/onboarding" element={<Onboarding />} />
// <Route path="/assessment-result" element={<AssessmentResult />} />
// <Route path="/career/:slug" element={<CareerCanvas />} />
