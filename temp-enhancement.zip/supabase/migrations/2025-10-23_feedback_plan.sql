
-- 2025-10-23_b: Feedback & Plan tables + RLS

create table if not exists public.feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  career_id uuid not null references public.careers(id) on delete cascade,
  label text not null check (label in ('like','dislike')),
  created_at timestamptz default now(),
  unique (user_id, career_id)
);

create table if not exists public.plan_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  item_type text not null check (item_type in ('career','course')),
  item_id uuid not null,
  created_at timestamptz default now()
);

alter table public.feedback enable row level security;
alter table public.plan_items enable row level security;

create policy if not exists "feedback_own_select"
on public.feedback for select to authenticated using (auth.uid() = user_id);

create policy if not exists "feedback_own_upsert"
on public.feedback for insert to authenticated with check (auth.uid() = user_id);

create policy if not exists "plan_own_select"
on public.plan_items for select to authenticated using (auth.uid() = user_id);

create policy if not exists "plan_own_upsert"
on public.plan_items for insert to authenticated with check (auth.uid() = user_id);
