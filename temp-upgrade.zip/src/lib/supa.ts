
// src/lib/supa.ts
import { createClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL!;
const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY!;

export const supa = createClient(url, key);
